export type JobType = 'fulltime' | 'parttime' | 'contract' | 'freelance' | 'internship';
export type JobExperienceLevel = 'entry' | 'mid' | 'senior';
export type ApplicationStatus = 'pending' | 'reviewing' | 'interviewed' | 'offered' | 'rejected' | 'accepted';

export interface FeaturedJob {
  id: number;
  title: string;
  companyName: string;
  companyLogo: string;
  location: string;
  salary: string;
  experience: string;
  skills: string[];
  isVerified: boolean;
  postedAt: string;
}

export interface CompanyInfo {
  id: number;
  name: string;
  logo: string;
  openJobs: number;
}

export interface Testimonial {
  id: number;
  content: string;
  userName: string;
  userAvatar: string;
  userTitle: string;
  company: string;
}

export interface SearchFilters {
  query?: string;
  location?: string;
  jobType?: JobType[];
  experienceLevel?: JobExperienceLevel[];
  skills?: string[];
  salaryMin?: number;
  salaryMax?: number;
}

export interface UserProfile {
  fullName: string;
  username: string;
  email: string;
  avatar?: string;
  phone?: string;
  bio?: string;
  location?: string;
  skills: string[];
  experience?: number;
  education?: string;
  resumeUrl?: string;
  preferredLanguage: string;
}
