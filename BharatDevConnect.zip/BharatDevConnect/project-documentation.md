# Bharat Dev - Project Code Structure

## Overview
Bharat Dev is a bilingual (English/Hindi) job board platform connecting Indian software developers with vetted global companies and startups, featuring AI-powered job matching, user verification, and company vetting.

## Project Structure

### Frontend Structure
- **client/src/main.tsx** - Entry point for the React application
- **client/src/App.tsx** - Main application component with routing
- **client/src/pages/** - Page components
- **client/src/components/** - Reusable UI components
- **client/src/hooks/** - Custom React hooks
- **client/src/lib/** - Utility functions and helpers

### Backend Structure
- **server/index.ts** - Express server entry point
- **server/routes.ts** - API route definitions
- **server/auth.ts** - Authentication setup using Passport.js
- **server/storage.ts** - Data storage interface and implementation
- **server/vite.ts** - Vite configuration for server-side rendering

### Shared
- **shared/schema.ts** - Database schema and types using Drizzle
- **shared/translations.ts** - Multilingual text content
- **shared/types.ts** - TypeScript type definitions

## Key Files and Their Purpose

### 1. Frontend Entry Points

#### client/src/main.tsx
```tsx
// React application entry point
// Initializes the application with all required providers
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { I18nProvider } from "./hooks/use-i18n";
import { AuthProvider } from "./hooks/use-auth";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";

// Debugging helper
const debugElement = document.createElement('div');
debugElement.id = 'debug-info';
// ... debug element styling ...
document.body.appendChild(debugElement);

const log = (message: string) => {
  console.log(`[DEBUG] ${message}`);
  const el = document.getElementById('debug-info');
  if (el) {
    el.textContent = message;
  }
};

// Create a root to render your app
try {
  log('Getting root element...');
  const rootElement = document.getElementById("root");
  if (!rootElement) {
    throw new Error('Root element not found');
  }
  
  log('Creating React root...');
  const root = createRoot(rootElement);
  
  log('Rendering app with providers...');
  // Wrap in error boundary
  root.render(
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <I18nProvider>
          <App />
        </I18nProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
  
  log('Render complete!');
} catch (error) {
  console.error('Error in app initialization:', error);
  // ... error handling ...
}
```

#### client/src/App.tsx
```tsx
// Main application component with routing configuration
import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import JobsPage from "@/pages/jobs-page";
import ProfilePage from "@/pages/profile-page";
import { ProtectedRoute } from "./lib/protected-route";
import Header from "./components/layout/Header";
import Footer from "./components/layout/Footer";
import { Suspense, useEffect } from "react";

// Simple fallback for lazy-loaded components
const LoadingFallback = () => (
  <div className="flex items-center justify-center min-h-[60vh]">
    <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary"></div>
  </div>
);

function Router() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <Switch>
        <Route path="/">
          <HomePage />
        </Route>
        <Route path="/auth">
          <AuthPage />
        </Route>
        <Route path="/jobs">
          <JobsPage />
        </Route>
        <ProtectedRoute path="/profile" component={ProfilePage} />
        <Route>
          <NotFound />
        </Route>
      </Switch>
    </Suspense>
  );
}

function App() {
  // Log visibility state to debug potential hidden elements
  useEffect(() => {
    console.log('App mounted');
    // ... debugging code ...
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <Router />
      </main>
      <Footer />
      <Toaster />
      <div id="app-status" className="fixed bottom-0 left-0 right-0 p-2 bg-green-500 text-white text-center">
        App Loaded Successfully
      </div>
    </div>
  );
}

export default App;
```

### 2. Pages

#### client/src/pages/home-page.tsx
```tsx
// Home page component displaying all sections of the landing page
import HeroSection from "@/components/home/HeroSection";
import StatsSection from "@/components/home/StatsSection";
import FeaturedJobs from "@/components/home/FeaturedJobs";
import AiMatchingSection from "@/components/home/AiMatchingSection";
import TopCompanies from "@/components/home/TopCompanies";
import Testimonials from "@/components/home/Testimonials";
import AppDownload from "@/components/home/AppDownload";
import SignUpCta from "@/components/home/SignUpCta";
import { useState, useEffect } from "react";

// Component containing all homepage sections
const HomePageContent = () => {
  return (
    <>
      <HeroSection />
      <StatsSection />
      <FeaturedJobs />
      <AiMatchingSection />
      <TopCompanies />
      <Testimonials />
      <AppDownload />
      <SignUpCta />
    </>
  );
};

// Error fallback component
const ErrorFallback = ({ error }: { error: Error }) => (
  <div className="container mx-auto px-4 py-16 text-center">
    <h2 className="text-2xl font-bold text-red-600 mb-4">Something went wrong:</h2>
    <pre className="bg-gray-100 p-4 rounded text-left overflow-x-auto">
      {error.message}
    </pre>
    <p className="mt-4">Please check the browser console for more details.</p>
  </div>
);

// Main HomePage component with error handling
const HomePage = () => {
  const [error, setError] = useState<Error | null>(null);
  const [renderCount, setRenderCount] = useState(0);

  useEffect(() => {
    console.log('HomePage mounted');
    setRenderCount(prev => prev + 1);
    
    // For debugging - add a simple fallback if components don't load
    const timer = setTimeout(() => {
      if (document.querySelectorAll('section').length === 0) {
        console.log('No sections found, possible rendering issue');
      }
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  try {
    if (error) throw error;

    return (
      <div>
        <div className="fixed top-0 right-0 bg-blue-500 text-white px-2 py-1 text-xs z-50">
          Render #{renderCount}
        </div>
        <HomePageContent />
      </div>
    );
  } catch (err) {
    console.error('Error in HomePage:', err);
    return <ErrorFallback error={err instanceof Error ? err : new Error('Unknown error')} />;
  }
};

export default HomePage;
```

#### client/src/pages/auth-page.tsx
```tsx
// Authentication page with login and registration forms
// Contains both login and registration forms with validation using zod
// Redirects authenticated users away from this page
import { useAuth } from "@/hooks/use-auth";
import { loginSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";

// Extended schemas with additional validation
const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string(),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

// Main authentication page component
export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [, setLocation] = useLocation();
  
  // Redirect if user is already logged in
  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);
  
  // Form submission handlers
  const onLoginSubmit = (values: LoginFormValues) => {
    loginMutation.mutate(values);
  };
  
  const onRegisterSubmit = (values: RegisterFormValues) => {
    const { confirmPassword, ...userData } = values;
    registerMutation.mutate(userData);
  };
  
  // Render login/registration UI
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 min-h-[calc(100vh-64px)]">
      {/* Form section */}
      <div className="flex items-center justify-center p-6">
        {/* Login/Register form components */}
      </div>
      
      {/* Hero section */}
      <div className="hidden md:block bg-gradient-to-r from-primary to-primary-700 text-white p-12 flex flex-col justify-center">
        {/* Hero content */}
      </div>
    </div>
  );
}
```

### 3. Home Page Components

#### client/src/components/home/HeroSection.tsx
```tsx
// Hero section component with search functionality
import { useI18n } from "@/hooks/use-i18n";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const HeroSection = () => {
  const { t } = useI18n();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [searchLocation, setSearchLocation] = useState("");

  const popularSearches = ["React", "Python", "Bangalore", "Remote", "Full Stack"];

  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Create query string with search parameters
    const params = new URLSearchParams();
    if (searchQuery) params.append("q", searchQuery);
    if (searchLocation) params.append("location", searchLocation);
    
    // Navigate to jobs page with search parameters
    setLocation(`/jobs?${params.toString()}`);
  };

  return (
    <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-12 md:py-20">
      <div className="container mx-auto px-4">
        {/* Hero content */}
        {/* Search form */}
        {/* Popular searches */}
        {/* Visual elements */}
      </div>
    </section>
  );
};

export default HeroSection;
```

### 4. Authentication Infrastructure

#### client/src/hooks/use-auth.tsx
```tsx
// Authentication context provider and hook
import { createContext, ReactNode, useContext, useState, useEffect } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { insertUserSchema, User as SelectUser, InsertUser, LoginData } from "@shared/schema";
import { getQueryFn, apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Define the shape of our authentication context
type AuthContextType = {
  user: SelectUser | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<SelectUser, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<SelectUser, Error, InsertUser>;
};

// Create context with a default value
export const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: false,
  error: null,
  // These will be properly initialized in the provider
  loginMutation: {} as UseMutationResult<SelectUser, Error, LoginData>,
  logoutMutation: {} as UseMutationResult<void, Error, void>,
  registerMutation: {} as UseMutationResult<SelectUser, Error, InsertUser>,
});

// Custom provider component
export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [initialized, setInitialized] = useState(false);
  
  // Fetch current user data
  const {
    data: user,
    error,
    isLoading,
  } = useQuery<SelectUser | null>({
    queryKey: ["/api/user"],
    queryFn: async () => {
      try {
        const response = await fetch("/api/user", {
          credentials: "include"
        });
        
        if (response.status === 401) {
          return null;
        }
        
        if (!response.ok) {
          throw new Error(`Error fetching user: ${response.statusText}`);
        }
        
        return await response.json();
      } catch (err) {
        console.error("Error fetching user:", err);
        return null;
      }
    },
    retry: false,
    refetchOnWindowFocus: false,
  });

  // Set initialized after first load
  useEffect(() => {
    if (!isLoading) {
      setInitialized(true);
    }
  }, [isLoading]);

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      const res = await apiRequest("POST", "/api/login", credentials);
      return await res.json();
    },
    onSuccess: (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Login successful",
        description: `Welcome back, ${user.username}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Register mutation
  const registerMutation = useMutation({
    mutationFn: async (credentials: InsertUser) => {
      const res = await apiRequest("POST", "/api/register", credentials);
      return await res.json();
    },
    onSuccess: (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Registration successful",
        description: "Your account has been created",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/logout");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/user"], null);
      toast({
        title: "Logged out",
        description: "You have been successfully logged out",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Provide loading state until first authentication check is complete
  if (!initialized) {
    return <div className="flex items-center justify-center min-h-screen">
      Loading authentication...
    </div>;
  }

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook for accessing auth context
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
```

#### client/src/lib/protected-route.tsx
```tsx
// Protected route component for authentication-required routes
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route } from "wouter";

export function ProtectedRoute({
  path,
  component: Component,
}: {
  path: string;
  component: () => React.JSX.Element;
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-border" />
        </div>
      </Route>
    );
  }

  if (!user) {
    return (
      <Route path={path}>
        <Redirect to="/auth" />
      </Route>
    );
  }

  return <Route path={path}><Component /></Route>;
}
```

### 5. Internationalization

#### client/src/hooks/use-i18n.tsx
```tsx
// Internationalization context provider and hook
import { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { translations } from '@shared/translations';

type LanguageCode = 'en' | 'hi';
type TranslationKey = keyof typeof translations.en;

interface I18nContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: TranslationKey) => string;
}

// Create context with default values to avoid the undefined check
const I18nContext = createContext<I18nContextType>({
  language: 'en',
  setLanguage: () => {},
  t: (key) => key as string
});

const getSavedLanguage = (): LanguageCode => {
  try {
    const savedLanguage = localStorage.getItem('language') as LanguageCode;
    return (savedLanguage === 'en' || savedLanguage === 'hi') ? savedLanguage : 'en';
  } catch (error) {
    console.error('Error accessing localStorage:', error);
    return 'en';
  }
};

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<LanguageCode>('en');
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize language preference after component mounts
  useEffect(() => {
    const savedLanguage = getSavedLanguage();
    setLanguage(savedLanguage);
    document.documentElement.lang = savedLanguage;
    document.documentElement.dir = 'ltr'; // Both English and Hindi are LTR
    setIsInitialized(true);
  }, []);

  const changeLanguage = (lang: LanguageCode) => {
    try {
      localStorage.setItem('language', lang);
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
    
    setLanguage(lang);
    document.documentElement.lang = lang;
  };

  const t = (key: TranslationKey): string => {
    try {
      const translationSet = translations[language];
      return translationSet && translationSet[key] 
        ? translationSet[key] 
        : translations.en[key] || key as string;
    } catch (error) {
      console.error(`Translation error for key: ${String(key)}`, error);
      return key as string;
    }
  };

  // Show minimal loading state until the language is initialized
  if (!isInitialized) {
    return <div className="flex items-center justify-center min-h-screen">
      Loading language settings...
    </div>;
  }

  return (
    <I18nContext.Provider
      value={{
        language,
        setLanguage: changeLanguage,
        t,
      }}
    >
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
}
```

### 6. Server-Side Authentication

#### server/auth.ts
```tsx
// Server-side authentication setup with Passport.js
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";
import createMemoryStore from "memorystore";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);
const MemoryStore = createMemoryStore(session);

// Hash passwords using scrypt
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// Compare provided password with stored hashed password
async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSecret = process.env.SESSION_SECRET || randomBytes(32).toString("hex");
  
  const sessionSettings: session.SessionOptions = {
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    store: new MemoryStore({
      checkPeriod: 86400000, // Prune expired entries every 24h
    }),
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    }
  };

  // Set up session middleware
  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure LocalStrategy for username/password login
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Invalid username or password" });
        }
        
        const isPasswordValid = await comparePasswords(password, user.password);
        if (!isPasswordValid) {
          return done(null, false, { message: "Invalid username or password" });
        }
        
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }),
  );

  // Serialize user to the session
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  // Deserialize user from the session
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Registration route
  app.post("/api/register", async (req, res, next) => {
    try {
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(req.body.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }

      // Hash the password
      const hashedPassword = await hashPassword(req.body.password);

      // Create user
      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword,
        skills: req.body.skills || [],
        preferredLanguage: req.body.preferredLanguage || "en",
        isVerified: false,
      });

      // Remove password from response
      const { password, ...userWithoutPassword } = user;

      // Log the user in
      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      next(error);
    }
  });

  // Login route
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info?.message || "Authentication failed" });
      }
      
      req.login(user, (loginErr) => {
        if (loginErr) return next(loginErr);
        
        // Remove password from response
        const { password, ...userWithoutPassword } = user;
        res.json(userWithoutPassword);
      });
    })(req, res, next);
  });

  // Logout route
  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  // Get current user
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Remove password from response
    const { password, ...userWithoutPassword } = req.user as SelectUser;
    res.json(userWithoutPassword);
  });

  // Middleware to check if user is authenticated
  const isAuthenticated = (req: Express.Request, res: Express.Response, next: Express.NextFunction) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Authentication required" });
  };

  return { isAuthenticated };
}
```

### 7. Database Schema

#### shared/schema.ts
```tsx
// Database schema definitions using Drizzle ORM
import { pgTable, text, serial, integer, boolean, jsonb, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  phone: text("phone"),
  avatar: text("avatar"),
  bio: text("bio"),
  skills: text("skills").array(),
  experience: integer("experience"),
  education: text("education"),
  preferredLanguage: text("preferred_language").default("en"),
  resumeUrl: text("resume_url"),
  location: text("location"),
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Company model
export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  logo: text("logo"),
  website: text("website"),
  description: text("description"),
  industry: text("industry"),
  size: text("size"),
  location: text("location"),
  isVerified: boolean("is_verified").default(false),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Job model
export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  requirements: text("requirements").notNull(),
  responsibilities: text("responsibilities").notNull(),
  location: text("location").notNull(),
  salary: text("salary"),
  experienceLevel: text("experience_level"),
  employmentType: text("employment_type").notNull(),
  skills: text("skills").array(),
  companyId: integer("company_id").references(() => companies.id),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Application model
export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  jobId: integer("job_id").references(() => jobs.id),
  status: text("status").default("pending"),
  coverLetter: text("cover_letter"),
  resumeUrl: text("resume_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Testimonial model
export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  content: text("content").notNull(),
  companyName: text("company_name"),
  jobTitle: text("job_title"),
  isApproved: boolean("is_approved").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users)
  .omit({ id: true, createdAt: true, isVerified: true });

export const insertCompanySchema = createInsertSchema(companies)
  .omit({ id: true, createdAt: true, isVerified: true });

export const insertJobSchema = createInsertSchema(jobs)
  .omit({ id: true, createdAt: true });

export const insertApplicationSchema = createInsertSchema(applications)
  .omit({ id: true, createdAt: true, status: true });

export const insertTestimonialSchema = createInsertSchema(testimonials)
  .omit({ id: true, createdAt: true, isApproved: true });

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companies.$inferSelect;

export type InsertJob = z.infer<typeof insertJobSchema>;
export type Job = typeof jobs.$inferSelect;

export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type Application = typeof applications.$inferSelect;

export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
export type Testimonial = typeof testimonials.$inferSelect;

// Login schema
export const loginSchema = z.object({
  username: z.string().min(1, { message: "Username is required" }),
  password: z.string().min(1, { message: "Password is required" }),
});

export type LoginData = z.infer<typeof loginSchema>;
```

### 8. Storage Implementation

#### server/storage.ts
```tsx
// In-memory storage implementation for the application data
import { User, InsertUser, Company, InsertCompany, Job, InsertJob, Application, InsertApplication, Testimonial, InsertTestimonial } from "@shared/schema";
import { FeaturedJob, CompanyInfo, SearchFilters } from "@shared/types";

// Storage interface defining all required operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User>;
  
  // Job operations
  getJob(id: number): Promise<Job | undefined>;
  getFeaturedJobs(): Promise<FeaturedJob[]>;
  searchJobs(filters: SearchFilters): Promise<FeaturedJob[]>;
  createJob(job: InsertJob): Promise<Job>;
  
  // Company operations
  getCompany(id: number): Promise<Company | undefined>;
  getTopCompanies(): Promise<CompanyInfo[]>;
  createCompany(company: InsertCompany): Promise<Company>;
  
  // Application operations
  getUserApplications(userId: number): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  
  // Saved jobs operations
  getUserSavedJobs(userId: number): Promise<FeaturedJob[]>;
  saveJob(userId: number, jobId: number): Promise<void>;
  unsaveJob(userId: number, jobId: number): Promise<void>;
  
  // Testimonial operations
  getTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
}

// In-memory implementation of storage
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private jobs: Map<number, Job>;
  private companies: Map<number, Company>;
  private applications: Map<number, Application>;
  private savedJobs: Map<number, Set<number>>;
  private testimonials: Map<number, Testimonial>;
  
  private nextUserId: number;
  private nextJobId: number;
  private nextCompanyId: number;
  private nextApplicationId: number;
  private nextTestimonialId: number;
  
  constructor() {
    this.users = new Map();
    this.jobs = new Map();
    this.companies = new Map();
    this.applications = new Map();
    this.savedJobs = new Map();
    this.testimonials = new Map();
    
    this.nextUserId = 1;
    this.nextJobId = 1;
    this.nextCompanyId = 1;
    this.nextApplicationId = 1;
    this.nextTestimonialId = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => 
      user.username.toLowerCase() === username.toLowerCase()
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => 
      user.email.toLowerCase() === email.toLowerCase()
    );
  }
  
  async createUser(userData: InsertUser): Promise<User> {
    const id = this.nextUserId++;
    
    const user: User = {
      id,
      ...userData,
      isVerified: false,
      createdAt: new Date(),
    };
    
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = {
      ...user,
      ...data,
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Job operations
  async getJob(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }
  
  async getFeaturedJobs(): Promise<FeaturedJob[]> {
    // Return a subset of jobs as featured
    const allJobs = Array.from(this.jobs.values())
      .filter(job => job.isActive)
      .slice(0, 6);
      
    return Promise.all(allJobs.map(async job => {
      const company = await this.getCompany(job.companyId);
      return this.convertToFeaturedJob(job);
    }));
  }
  
  async searchJobs(filters: SearchFilters): Promise<FeaturedJob[]> {
    let filteredJobs = Array.from(this.jobs.values()).filter(job => job.isActive);
    
    // Apply filters
    if (filters.query) {
      const query = filters.query.toLowerCase();
      filteredJobs = filteredJobs.filter(job => 
        job.title.toLowerCase().includes(query) || 
        job.description.toLowerCase().includes(query) ||
        job.skills.some(skill => skill.toLowerCase().includes(query))
      );
    }
    
    if (filters.location) {
      const location = filters.location.toLowerCase();
      filteredJobs = filteredJobs.filter(job => 
        job.location.toLowerCase().includes(location)
      );
    }
    
    if (filters.jobType && filters.jobType.length > 0) {
      filteredJobs = filteredJobs.filter(job => 
        filters.jobType!.includes(job.employmentType as any)
      );
    }
    
    if (filters.experienceLevel && filters.experienceLevel.length > 0) {
      filteredJobs = filteredJobs.filter(job => 
        filters.experienceLevel!.includes(job.experienceLevel as any)
      );
    }
    
    if (filters.skills && filters.skills.length > 0) {
      filteredJobs = filteredJobs.filter(job => 
        filters.skills!.some(skill => 
          job.skills.includes(skill)
        )
      );
    }
    
    // Handle salary range filter if needed
    
    return Promise.all(filteredJobs.map(job => this.convertToFeaturedJob(job)));
  }
  
  async createJob(jobData: InsertJob): Promise<Job> {
    const id = this.nextJobId++;
    
    const job: Job = {
      id,
      ...jobData,
      isActive: true,
      createdAt: new Date(),
    };
    
    this.jobs.set(id, job);
    return job;
  }
  
  // Company operations
  async getCompany(id: number): Promise<Company | undefined> {
    return this.companies.get(id);
  }
  
  async getTopCompanies(): Promise<CompanyInfo[]> {
    return Array.from(this.companies.values())
      .slice(0, 6)
      .map(company => ({
        id: company.id,
        name: company.name,
        logo: company.logo || "",
        openJobs: Array.from(this.jobs.values()).filter(job => 
          job.companyId === company.id && job.isActive
        ).length,
      }));
  }
  
  async createCompany(companyData: InsertCompany): Promise<Company> {
    const id = this.nextCompanyId++;
    
    const company: Company = {
      id,
      ...companyData,
      isVerified: false,
      createdAt: new Date(),
    };
    
    this.companies.set(id, company);
    return company;
  }
  
  // Application operations
  async getUserApplications(userId: number): Promise<Application[]> {
    return Array.from(this.applications.values())
      .filter(application => application.userId === userId);
  }
  
  async createApplication(applicationData: InsertApplication): Promise<Application> {
    const id = this.nextApplicationId++;
    
    const application: Application = {
      id,
      ...applicationData,
      status: "pending",
      createdAt: new Date(),
    };
    
    this.applications.set(id, application);
    return application;
  }
  
  // Saved jobs operations
  async getUserSavedJobs(userId: number): Promise<FeaturedJob[]> {
    const savedJobIds = this.savedJobs.get(userId) || new Set<number>();
    
    const savedJobs = Array.from(savedJobIds)
      .map(jobId => this.jobs.get(jobId))
      .filter(job => job !== undefined && job.isActive) as Job[];
      
    return Promise.all(savedJobs.map(job => this.convertToFeaturedJob(job)));
  }
  
  async saveJob(userId: number, jobId: number): Promise<void> {
    if (!this.savedJobs.has(userId)) {
      this.savedJobs.set(userId, new Set<number>());
    }
    
    this.savedJobs.get(userId)!.add(jobId);
  }
  
  async unsaveJob(userId: number, jobId: number): Promise<void> {
    if (this.savedJobs.has(userId)) {
      this.savedJobs.get(userId)!.delete(jobId);
    }
  }
  
  // Testimonial operations
  async getTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values())
      .filter(testimonial => testimonial.isApproved);
  }
  
  async createTestimonial(testimonialData: InsertTestimonial): Promise<Testimonial> {
    const id = this.nextTestimonialId++;
    
    const testimonial: Testimonial = {
      id,
      ...testimonialData,
      isApproved: false,
      createdAt: new Date(),
    };
    
    this.testimonials.set(id, testimonial);
    return testimonial;
  }
  
  // Helper methods
  private convertToFeaturedJob(job: Job): FeaturedJob {
    const company = this.companies.get(job.companyId);
    
    return {
      id: job.id,
      title: job.title,
      companyName: company?.name || "Unknown Company",
      companyLogo: company?.logo || "",
      location: job.location,
      salary: job.salary || "",
      experience: job.experienceLevel || "",
      skills: job.skills || [],
      isVerified: company?.isVerified || false,
      postedAt: this.getRelativeTime(job.createdAt),
    };
  }
  
  private getRelativeTime(date: Date): string {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return `${diffInSeconds} seconds ago`;
    }
    
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    if (diffInMinutes < 60) {
      return `${diffInMinutes} minutes ago`;
    }
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
      return `${diffInHours} hours ago`;
    }
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 30) {
      return `${diffInDays} days ago`;
    }
    
    const diffInMonths = Math.floor(diffInDays / 30);
    return `${diffInMonths} months ago`;
  }
  
  // Initialize sample data for development
  private initializeSampleData() {
    // Sample companies
    const googleId = this.createSampleCompany({
      name: "Google",
      logo: "https://logo.clearbit.com/google.com",
      website: "https://google.com",
      industry: "Technology",
      size: "10000+",
      location: "Bangalore, India",
      isVerified: true,
    });
    
    const microsoftId = this.createSampleCompany({
      name: "Microsoft",
      logo: "https://logo.clearbit.com/microsoft.com",
      website: "https://microsoft.com",
      industry: "Technology",
      size: "10000+",
      location: "Hyderabad, India",
      isVerified: true,
    });
    
    // More sample companies...
    
    // Sample jobs
    this.createSampleJob({
      title: "Senior Frontend Engineer",
      description: "Join our team to build world-class web applications using React and TypeScript.",
      requirements: "5+ years of experience with modern JavaScript frameworks",
      responsibilities: "Lead development of key frontend features",
      location: "Bangalore, India",
      salary: "₹20,00,000 - ₹30,00,000",
      experienceLevel: "senior",
      employmentType: "fulltime",
      skills: ["React", "TypeScript", "Redux", "HTML", "CSS"],
      companyId: googleId,
    });
    
    this.createSampleJob({
      title: "Backend Developer",
      description: "Build scalable backend systems using Node.js and MongoDB.",
      requirements: "3+ years of experience with Node.js",
      responsibilities: "Design and implement API endpoints, database schemas",
      location: "Remote",
      salary: "₹15,00,000 - ₹25,00,000",
      experienceLevel: "mid",
      employmentType: "fulltime",
      skills: ["Node.js", "Express", "MongoDB", "REST API", "GraphQL"],
      companyId: microsoftId,
    });
    
    // More sample jobs...
    
    // Sample testimonials
    this.createSampleTestimonial({
      userId: 1,
      content: "BharatDev helped me find my dream job at a top tech company in just 2 weeks! The AI matching was incredibly accurate.",
      companyName: "TechGiant",
      jobTitle: "Senior Developer",
      isApproved: true,
    });
    
    // More sample testimonials...
  }
  
  private createSampleCompany(data: Partial<Company>): number {
    const id = this.nextCompanyId++;
    
    const company: Company = {
      id,
      name: data.name || "Unknown Company",
      logo: data.logo,
      website: data.website,
      description: data.description,
      industry: data.industry,
      size: data.size,
      location: data.location,
      isVerified: data.isVerified || false,
      userId: data.userId,
      createdAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000), // Random date within last 30 days
    };
    
    this.companies.set(id, company);
    return id;
  }
  
  private createSampleJob(data: Partial<Job>): number {
    const id = this.nextJobId++;
    
    const job: Job = {
      id,
      title: data.title || "Untitled Job",
      description: data.description || "",
      requirements: data.requirements || "",
      responsibilities: data.responsibilities || "",
      location: data.location || "Remote",
      salary: data.salary,
      experienceLevel: data.experienceLevel,
      employmentType: data.employmentType || "fulltime",
      skills: data.skills || [],
      companyId: data.companyId || 1,
      isActive: true,
      createdAt: new Date(Date.now() - Math.random() * 14 * 24 * 60 * 60 * 1000), // Random date within last 14 days
    };
    
    this.jobs.set(id, job);
    return id;
  }
  
  private createSampleTestimonial(data: Partial<Testimonial>): number {
    const id = this.nextTestimonialId++;
    
    const testimonial: Testimonial = {
      id,
      userId: data.userId,
      content: data.content || "",
      companyName: data.companyName,
      jobTitle: data.jobTitle,
      isApproved: data.isApproved || false,
      createdAt: new Date(Date.now() - Math.random() * 60 * 24 * 60 * 60 * 1000), // Random date within last 60 days
    };
    
    this.testimonials.set(id, testimonial);
    return id;
  }
}

// Export a singleton instance of the storage
export const storage = new MemStorage();
```

### 9. API Routes

#### server/routes.ts
```tsx
// API routes for the Express server
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";
import { insertJobSchema, insertApplicationSchema, insertTestimonialSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  const { isAuthenticated } = setupAuth(app);

  // Configure multer for file uploads
  const uploadDir = path.join(process.cwd(), "uploads");
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }

  const storage_config = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueFilename = `${uuidv4()}-${file.originalname}`;
      cb(null, uniqueFilename);
    },
  });

  const upload = multer({
    storage: storage_config,
    limits: {
      fileSize: 5 * 1024 * 1024, // 5MB limit
    },
    fileFilter: (req, file, cb) => {
      const allowedTypes = ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error("Only PDF, DOC, and DOCX files are allowed"));
      }
    },
  });

  // Profile routes
  app.get("/api/profile", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error fetching profile", error: (error as Error).message });
    }
  });

  // More route handlers for user profile, jobs, applications, companies, testimonials...

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
```

## Technologies Used

### Frontend
- **React** - UI library
- **TypeScript** - Type-safe JavaScript
- **Vite** - Build tool and dev server
- **TanStack Query** - Data fetching and caching
- **React Hook Form** - Form handling
- **Zod** - Schema validation
- **Wouter** - Routing
- **Tailwind CSS** - Utility-first CSS
- **Shadcn UI** - UI component library

### Backend
- **Node.js** - JavaScript runtime
- **Express** - Web framework
- **Passport.js** - Authentication
- **Drizzle ORM** - Database ORM
- **Multer** - File uploads

### Database
- **In-memory storage** - Used for development
- **PostgreSQL schema** - Defined for future persistence

## Features

1. **Bilingual Support**
   - English and Hindi language support
   - Language preference saved in localStorage
   - Translation system for UI text

2. **Authentication**
   - User registration and login
   - Secure password hashing with scrypt
   - Protected routes for authenticated users

3. **Job Search**
   - Job listings with filtering
   - AI-powered job matching (conceptual)
   - Company profiles and verification

4. **User Profiles**
   - Profile management
   - Resume upload
   - Job application tracking

5. **Responsive Design**
   - Mobile, tablet, and desktop compatibility
   - Accessibility features
   - Modern UI with Tailwind CSS