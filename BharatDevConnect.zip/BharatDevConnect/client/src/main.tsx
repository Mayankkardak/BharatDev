import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { I18nProvider } from "./hooks/use-i18n";
import { AuthProvider } from "./hooks/use-auth";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";

// Debugging helper
const debugElement = document.createElement('div');
debugElement.id = 'debug-info';
debugElement.style.position = 'fixed';
debugElement.style.bottom = '10px';
debugElement.style.right = '10px';
debugElement.style.backgroundColor = 'rgba(0,0,0,0.7)';
debugElement.style.color = 'white';
debugElement.style.padding = '10px';
debugElement.style.zIndex = '9999';
debugElement.style.maxWidth = '300px';
debugElement.style.maxHeight = '200px';
debugElement.style.overflow = 'auto';
debugElement.style.fontSize = '12px';
debugElement.textContent = 'Debug: App initializing...';
document.body.appendChild(debugElement);

const log = (message: string) => {
  console.log(`[DEBUG] ${message}`);
  const el = document.getElementById('debug-info');
  if (el) {
    el.textContent = message;
  }
};

// Create a root to render your app
try {
  log('Getting root element...');
  const rootElement = document.getElementById("root");
  if (!rootElement) {
    throw new Error('Root element not found');
  }
  
  log('Creating React root...');
  const root = createRoot(rootElement);
  
  log('Rendering app with providers...');
  // Wrap in error boundary
  root.render(
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <I18nProvider>
          <App />
        </I18nProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
  
  log('Render complete!');
} catch (error) {
  console.error('Error in app initialization:', error);
  const rootElem = document.getElementById("root");
  if (rootElem) {
    rootElem.innerHTML = `<div style="color: red; padding: 20px; font-family: sans-serif;">
      <h2>App Initialization Error</h2>
      <p>${error instanceof Error ? error.message : String(error)}</p>
      <p>Check console for more details</p>
    </div>`;
  }
  log(`ERROR: ${error instanceof Error ? error.message : String(error)}`);
}
