import { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { translations } from '@shared/translations';

type LanguageCode = 'en' | 'hi';
type TranslationKey = keyof typeof translations.en;

interface I18nContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: TranslationKey) => string;
}

// Create context with default values to avoid the undefined check
const I18nContext = createContext<I18nContextType>({
  language: 'en',
  setLanguage: () => {},
  t: (key) => key as string
});

const getSavedLanguage = (): LanguageCode => {
  try {
    const savedLanguage = localStorage.getItem('language') as LanguageCode;
    return (savedLanguage === 'en' || savedLanguage === 'hi') ? savedLanguage : 'en';
  } catch (error) {
    console.error('Error accessing localStorage:', error);
    return 'en';
  }
};

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<LanguageCode>('en');
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize language preference after component mounts
  useEffect(() => {
    const savedLanguage = getSavedLanguage();
    setLanguage(savedLanguage);
    document.documentElement.lang = savedLanguage;
    document.documentElement.dir = 'ltr'; // Both English and Hindi are LTR
    setIsInitialized(true);
  }, []);

  const changeLanguage = (lang: LanguageCode) => {
    try {
      localStorage.setItem('language', lang);
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
    
    setLanguage(lang);
    document.documentElement.lang = lang;
  };

  const t = (key: TranslationKey): string => {
    try {
      const translationSet = translations[language];
      return translationSet && translationSet[key] 
        ? translationSet[key] 
        : translations.en[key] || key as string;
    } catch (error) {
      console.error(`Translation error for key: ${String(key)}`, error);
      return key as string;
    }
  };

  // Show minimal loading state until the language is initialized
  if (!isInitialized) {
    return <div className="flex items-center justify-center min-h-screen">
      Loading language settings...
    </div>;
  }

  return (
    <I18nContext.Provider
      value={{
        language,
        setLanguage: changeLanguage,
        t,
      }}
    >
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
}
