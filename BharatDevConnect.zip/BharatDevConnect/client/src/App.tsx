import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import JobsPage from "@/pages/jobs-page";
import ProfilePage from "@/pages/profile-page";
import { ProtectedRoute } from "./lib/protected-route";
import Header from "./components/layout/Header";
import Footer from "./components/layout/Footer";
import { Suspense, useEffect } from "react";

// Simple fallback for lazy-loaded components
const LoadingFallback = () => (
  <div className="flex items-center justify-center min-h-[60vh]">
    <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary"></div>
  </div>
);

function Router() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <Switch>
        <Route path="/">
          <HomePage />
        </Route>
        <Route path="/auth">
          <AuthPage />
        </Route>
        <Route path="/jobs">
          <JobsPage />
        </Route>
        <ProtectedRoute path="/profile" component={ProfilePage} />
        <Route>
          <NotFound />
        </Route>
      </Switch>
    </Suspense>
  );
}

function App() {
  // Log visibility state to debug potential hidden elements
  useEffect(() => {
    console.log('App mounted');
    // Log visibility of main container after a short delay
    setTimeout(() => {
      const mainElement = document.querySelector('main');
      if (mainElement) {
        const styles = window.getComputedStyle(mainElement);
        console.log('Main element styles:', {
          display: styles.display,
          visibility: styles.visibility,
          height: styles.height,
          opacity: styles.opacity
        });
      } else {
        console.log('Main element not found');
      }
    }, 500);
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <Router />
      </main>
      <Footer />
      <Toaster />
      <div id="app-status" className="fixed bottom-0 left-0 right-0 p-2 bg-green-500 text-white text-center">
        App Loaded Successfully
      </div>
    </div>
  );
}

export default App;
