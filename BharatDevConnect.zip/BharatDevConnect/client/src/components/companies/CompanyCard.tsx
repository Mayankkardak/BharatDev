import { CompanyInfo } from "@shared/types";
import { useI18n } from "@/hooks/use-i18n";
import { Card, CardContent } from "@/components/ui/card";

interface CompanyCardProps {
  company: CompanyInfo;
}

const CompanyCard = ({ company }: CompanyCardProps) => {
  const { t } = useI18n();

  return (
    <Card className="flex flex-col items-center p-6 bg-slate-50 rounded-lg hover:shadow-md transition">
      <CardContent className="p-0 flex flex-col items-center w-full">
        <div className="w-16 h-16 bg-white rounded-md p-2 flex items-center justify-center mb-4">
          {company.logo ? (
            <img 
              src={company.logo} 
              alt={company.name} 
              className="w-12 h-12 object-contain"
            />
          ) : (
            <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center text-primary text-lg font-bold">
              {company.name.charAt(0)}
            </div>
          )}
        </div>
        <h3 className="font-medium text-center">{company.name}</h3>
        <p className="text-sm text-slate-500 text-center mt-1">
          {company.openJobs} {t("home.openJobs")}
        </p>
      </CardContent>
    </Card>
  );
};

export default CompanyCard;
