import { useI18n } from "@/hooks/use-i18n";
import { FeaturedJob } from "@shared/types";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { 
  MapPin, 
  BriefcaseBusiness, 
  IndianRupee, 
  Bookmark, 
  Clock, 
  CheckCircle 
} from "lucide-react";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";

interface JobCardProps {
  job: FeaturedJob;
}

const JobCard = ({ job }: JobCardProps) => {
  const { t } = useI18n();
  const [isSaved, setIsSaved] = useState(false);

  const toggleSave = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsSaved(!isSaved);
  };

  return (
    <Card className="bg-white rounded-lg shadow-sm border border-slate-200 hover:shadow-md transition">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center">
            <div className={`bg-blue-50 p-3 rounded-md mr-4 w-12 h-12 flex items-center justify-center`}>
              {job.companyLogo ? (
                <img 
                  src={job.companyLogo} 
                  alt={job.companyName} 
                  className="w-10 h-10 object-contain" 
                />
              ) : (
                <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center text-primary text-lg font-bold">
                  {job.companyName.charAt(0)}
                </div>
              )}
            </div>
            <div>
              <h3 className="font-medium text-lg">{job.title}</h3>
              <div className="text-primary font-medium text-sm">{job.companyName}</div>
            </div>
          </div>
          <button 
            onClick={toggleSave}
            className={`${isSaved ? 'text-primary' : 'text-slate-400'} hover:text-primary-500`}
            aria-label={isSaved ? "Unsave job" : "Save job"}
          >
            <Bookmark className={`h-5 w-5 ${isSaved ? 'fill-primary' : ''}`} />
          </button>
        </div>
        
        <div className="mb-4">
          <div className="flex flex-wrap gap-2 mb-3">
            {job.skills.map((skill, index) => (
              <Badge key={index} variant="secondary" className="bg-blue-50 text-blue-700 hover:bg-blue-100">
                {skill}
              </Badge>
            ))}
          </div>
          
          <div className="flex flex-wrap items-center text-slate-500 text-sm gap-4">
            <div className="flex items-center">
              <MapPin className="h-4 w-4 mr-1" />
              <span>{job.location}</span>
            </div>
            <div className="flex items-center">
              <IndianRupee className="h-4 w-4 mr-1" />
              <span>{job.salary}</span>
            </div>
            <div className="flex items-center">
              <BriefcaseBusiness className="h-4 w-4 mr-1" />
              <span>{job.experience}</span>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            {job.isVerified && (
              <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                <CheckCircle className="h-3 w-3 mr-1" />
                {t("job.verified")}
              </Badge>
            )}
          </div>
          <div className="text-slate-500 text-sm flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            {job.postedAt}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default JobCard;
