import { useI18n } from "@/hooks/use-i18n";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const HeroSection = () => {
  const { t } = useI18n();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [searchLocation, setSearchLocation] = useState("");

  const popularSearches = ["React", "Python", "Bangalore", "Remote", "Full Stack"];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Create query string with search parameters
    const params = new URLSearchParams();
    if (searchQuery) params.append("q", searchQuery);
    if (searchLocation) params.append("location", searchLocation);
    
    // Navigate to jobs page with search parameters
    setLocation(`/jobs?${params.toString()}`);
  };

  return (
    <section className="bg-gradient-to-r from-primary to-primary-700 text-white py-12 md:py-20">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6 md:pr-12">
            <h1 className="font-poppins font-bold text-3xl md:text-4xl lg:text-5xl">
              {t("home.hero.title")}
              <span className="block mt-2 text-orange-300">{t("app.tagline")}</span>
            </h1>
            <p className="text-lg text-blue-100">
              {t("home.hero.subtitle")}
            </p>
            
            {/* Search Form */}
            <form onSubmit={handleSearch} className="bg-white rounded-lg p-1 shadow-lg flex flex-col sm:flex-row">
              <div className="flex-grow flex items-center px-4 py-2">
                <Search className="text-slate-400 mr-3 h-5 w-5" />
                <Input 
                  type="text" 
                  placeholder={t("home.search.jobTitle")}
                  className="w-full outline-none border-none focus-visible:ring-0 focus-visible:ring-offset-0"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex-grow flex items-center px-4 py-2 border-t sm:border-t-0 sm:border-l border-slate-100">
                <MapPin className="text-slate-400 mr-3 h-5 w-5" />
                <Input 
                  type="text" 
                  placeholder={t("home.search.location")}
                  className="w-full outline-none border-none focus-visible:ring-0 focus-visible:ring-offset-0"
                  value={searchLocation}
                  onChange={(e) => setSearchLocation(e.target.value)}
                />
              </div>
              <Button 
                type="submit"
                className="w-full sm:w-auto mt-1 sm:mt-0 bg-primary hover:bg-primary-600"
              >
                {t("home.search.button")}
              </Button>
            </form>
            
            <div className="flex flex-wrap gap-2 text-sm">
              <span className="text-blue-100">{t("home.popular")}</span>
              {popularSearches.map((term, index) => (
                <Link key={index} href={`/jobs?q=${term}`}>
                  <Badge 
                    variant="outline" 
                    className="px-2 py-1 bg-primary-400/30 hover:bg-primary-400/50 text-white border-transparent cursor-pointer"
                  >
                    {term}
                  </Badge>
                </Link>
              ))}
            </div>
          </div>
          
          <div className="hidden md:block relative">
            <div className="rounded-lg shadow-xl w-full overflow-hidden h-[400px] bg-gradient-to-br from-blue-900/40 to-indigo-900/40">
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 800 600" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#4338ca" stopOpacity="0.3" />
                    <stop offset="100%" stopColor="#3730a3" stopOpacity="0.6" />
                  </linearGradient>
                </defs>
                <rect width="100%" height="100%" fill="url(#grad)" />
                <circle cx="400" cy="300" r="200" fill="none" stroke="#6366f1" strokeWidth="2" strokeDasharray="10,10" opacity="0.2" />
                <circle cx="400" cy="300" r="150" fill="none" stroke="#6366f1" strokeWidth="2" strokeDasharray="10,10" opacity="0.4" />
                <circle cx="400" cy="300" r="100" fill="none" stroke="#6366f1" strokeWidth="2" strokeDasharray="10,10" opacity="0.6" />
                <circle cx="400" cy="300" r="50" fill="none" stroke="#6366f1" strokeWidth="2" strokeDasharray="10,10" opacity="0.8" />
              </svg>

              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center w-full">
                <div className="bg-white/10 backdrop-blur-md p-6 rounded-xl shadow-lg max-w-md mx-auto">
                  <h3 className="text-white text-xl font-bold mb-2">Connect with Top Tech Companies</h3>
                  <p className="text-blue-100 mb-4">Global corporations and innovative startups across India</p>
                  <div className="flex justify-center space-x-3">
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                      <span className="font-bold text-white">G</span>
                    </div>
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                      <span className="font-bold text-white">M</span>
                    </div>
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                      <span className="font-bold text-white">A</span>
                    </div>
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                      <span className="font-bold text-white">F</span>
                    </div>
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                      <span className="font-bold text-white">+</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <p className="text-slate-800 font-medium">AI-Powered Matching</p>
                  <p className="text-slate-500 text-sm">Find the perfect fit for your skills</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
