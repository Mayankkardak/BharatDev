import { useI18n } from "@/hooks/use-i18n";

const StatsSection = () => {
  const { t } = useI18n();
  
  const stats = [
    { value: "10,000+", label: "Active Jobs" },
    { value: "2,500+", label: "Verified Companies" },
    { value: "50,000+", label: "Developers" },
    { value: "85%", label: "Success Rate" }
  ];

  return (
    <section className="py-10 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {stats.map((stat, index) => (
            <div key={index} className="p-6">
              <div className="text-3xl font-bold text-primary mb-2">{stat.value}</div>
              <div className="text-slate-600">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
