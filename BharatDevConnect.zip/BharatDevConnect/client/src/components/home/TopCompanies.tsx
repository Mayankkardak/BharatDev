import { useI18n } from "@/hooks/use-i18n";
import { useQuery } from "@tanstack/react-query";
import { CompanyInfo } from "@shared/types";
import { Link } from "wouter";
import CompanyCard from "@/components/companies/CompanyCard";
import { ArrowRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const TopCompanies = () => {
  const { t } = useI18n();
  
  const { data: companies, isLoading } = useQuery<CompanyInfo[]>({
    queryKey: ["/api/companies/top"],
  });

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="font-poppins font-semibold text-2xl mb-8 text-center">{t("home.companies.title")}</h2>
        
        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="flex flex-col items-center p-6 bg-slate-50 rounded-lg">
                <Skeleton className="w-16 h-16 rounded-full mb-4" />
                <Skeleton className="h-5 w-24 mb-2" />
                <Skeleton className="h-4 w-16" />
              </div>
            ))}
          </div>
        ) : companies && companies.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {companies.map((company) => (
              <Link key={company.id} href={`/companies/${company.id}`}>
                <CompanyCard company={company} />
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-slate-500">No companies available currently.</p>
          </div>
        )}
        
        <div className="text-center mt-8">
          <Link href="/companies" className="text-primary hover:text-primary-600 font-medium inline-flex items-center">
            {t("home.companies.viewAll")}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default TopCompanies;
