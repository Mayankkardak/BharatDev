import { useI18n } from "@/hooks/use-i18n";
import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { useEffect, useState } from "react";

interface TestimonialData {
  id: number;
  content: string;
  userId: number | null;
  companyName: string | null;
  jobTitle: string | null;
  isApproved: boolean | null;
  createdAt: string | null;
  // Used to store derived user data
  userName?: string;
  userAvatar?: string;
}

const Testimonials = () => {
  const { t } = useI18n();
  const [processedTestimonials, setProcessedTestimonials] = useState<TestimonialData[]>([]);
  
  const { data: testimonials, isLoading: isTestimonialsLoading } = useQuery<TestimonialData[]>({
    queryKey: ["/api/testimonials"],
  });

  const { data: users, isLoading: isUsersLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    // We'll keep this query disabled since we're not implementing user fetching yet
    enabled: false,
  });

  // Process testimonials to add user data
  useEffect(() => {
    if (testimonials) {
      const processed = testimonials.map(testimonial => ({
        ...testimonial,
        userName: testimonial.companyName || "Anonymous User",
        userAvatar: "",
      }));
      setProcessedTestimonials(processed);
    }
  }, [testimonials]);

  const isLoading = isTestimonialsLoading || isUsersLoading;

  // Safe way to get the first character
  const getInitial = (name: string | undefined) => {
    if (!name || name.length === 0) return "U";
    return name.charAt(0);
  };

  return (
    <section className="py-16 bg-slate-50">
      <div className="container mx-auto px-4">
        <h2 className="font-poppins font-semibold text-2xl mb-2 text-center">{t("home.testimonials.title")}</h2>
        <p className="text-slate-600 text-center mb-12 max-w-2xl mx-auto">{t("home.testimonials.subtitle")}</p>
        
        {isLoading ? (
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="bg-white rounded-lg shadow relative">
                <CardContent className="p-6 pt-10">
                  <div className="space-y-4">
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-3/4" />
                    
                    <div className="flex items-center mt-4 pt-4">
                      <Skeleton className="w-12 h-12 rounded-full mr-4" />
                      <div>
                        <Skeleton className="h-4 w-24 mb-2" />
                        <Skeleton className="h-3 w-32" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : processedTestimonials && processedTestimonials.length > 0 ? (
          <div className="grid md:grid-cols-3 gap-8">
            {processedTestimonials.map((testimonial) => (
              <Card key={testimonial.id} className="bg-white p-6 rounded-lg shadow relative">
                <div className="text-orange-500 absolute -top-4 left-6 text-5xl">"</div>
                <CardContent className="p-0 pt-4">
                  <p className="text-slate-700 mb-6">
                    {testimonial.content}
                  </p>
                  
                  <div className="flex items-center">
                    {testimonial.userAvatar ? (
                      <img 
                        src={testimonial.userAvatar} 
                        alt={testimonial.userName || "User"} 
                        className="w-12 h-12 rounded-full object-cover mr-4"
                      />
                    ) : (
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary font-semibold mr-4">
                        {getInitial(testimonial.userName)}
                      </div>
                    )}
                    <div>
                      <h4 className="font-medium">{testimonial.userName || "Anonymous User"}</h4>
                      <p className="text-sm text-slate-500">
                        {testimonial.jobTitle || "Professional"} 
                        {testimonial.companyName ? ` at ${testimonial.companyName}` : ""}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-slate-500">No testimonials available currently.</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default Testimonials;
