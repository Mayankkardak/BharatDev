import { useI18n } from "@/hooks/use-i18n";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";

const SignUpCta = () => {
  const { t } = useI18n();
  const { user } = useAuth();

  if (user) {
    // Don't show CTA for logged in users
    return null;
  }

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="bg-gradient-to-r from-primary-50 to-blue-50 rounded-2xl p-8 md:p-12">
          <div className="text-center space-y-6">
            <h2 className="font-poppins font-bold text-2xl md:text-3xl text-primary-700">
              {t("home.cta.title")}
            </h2>
            
            <p className="text-slate-600 max-w-2xl mx-auto">
              {t("home.cta.description")}
            </p>
            
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center mt-4">
              <Link href="/auth">
                <Button className="bg-primary hover:bg-primary-600 text-white font-medium py-3 px-8 rounded-md transition text-center">
                  {t("home.cta.button")}
                </Button>
              </Link>
              
              <Link href="/jobs">
                <Button variant="outline" className="bg-white hover:bg-slate-50 text-primary font-medium py-3 px-8 rounded-md border border-primary-200 transition text-center">
                  {t("home.cta.learnMore")}
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SignUpCta;
