import { useI18n } from "@/hooks/use-i18n";
import { FeaturedJob } from "@shared/types";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import JobCard from "@/components/jobs/JobCard";
import { ArrowRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const FeaturedJobs = () => {
  const { t } = useI18n();
  
  const { data: jobs, isLoading } = useQuery<FeaturedJob[]>({
    queryKey: ["/api/jobs/featured"],
  });

  return (
    <section className="py-12 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="font-poppins font-semibold text-2xl">{t("home.featured.title")}</h2>
          <Link href="/jobs" className="text-primary hover:text-primary-600 font-medium flex items-center">
            {t("home.featured.viewAll")}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
        
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-lg p-6 space-y-4">
                <div className="flex items-start">
                  <Skeleton className="h-12 w-12 rounded-md mr-4" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-5 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex gap-2">
                    <Skeleton className="h-5 w-16 rounded-full" />
                    <Skeleton className="h-5 w-20 rounded-full" />
                    <Skeleton className="h-5 w-16 rounded-full" />
                  </div>
                  <div className="flex gap-4">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
                <div className="flex justify-between">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-5 w-24" />
                </div>
              </div>
            ))}
          </div>
        ) : jobs && jobs.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {jobs.map((job) => (
              <Link key={job.id} href={`/jobs/${job.id}`}>
                <JobCard job={job} />
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-slate-500">No featured jobs available currently.</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default FeaturedJobs;
