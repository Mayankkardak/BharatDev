import { useI18n } from "@/hooks/use-i18n";
import { Apple, PlayCircle } from "lucide-react";

const AppDownload = () => {
  const { t } = useI18n();

  return (
    <section className="py-12 bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-8 md:mb-0 text-center md:text-left">
            <h2 className="font-poppins font-semibold text-2xl mb-2">Download the BharatDev App</h2>
            <p className="text-blue-100 max-w-md">Get job alerts, track your applications, and connect with employers on the go.</p>
            
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 mt-6">
              <a href="#" className="bg-black text-white py-3 px-6 rounded-lg flex items-center justify-center">
                <Apple className="h-6 w-6 mr-3" />
                <div className="text-left">
                  <div className="text-xs">Download on the</div>
                  <div className="font-medium">App Store</div>
                </div>
              </a>
              
              <a href="#" className="bg-black text-white py-3 px-6 rounded-lg flex items-center justify-center">
                <PlayCircle className="h-6 w-6 mr-3" />
                <div className="text-left">
                  <div className="text-xs">Get it on</div>
                  <div className="font-medium">Google Play</div>
                </div>
              </a>
            </div>
          </div>
          
          <div className="relative">
            <div className="w-[200px] h-[400px] rounded-xl shadow-xl border-4 border-white/20 bg-gradient-to-b from-slate-900 to-slate-800 overflow-hidden">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center p-4">
                  <div className="h-10 w-10 rounded-lg bg-primary-400 flex items-center justify-center mx-auto mb-4">
                    <span className="text-white font-bold font-poppins text-lg">बD</span>
                  </div>
                  <h3 className="text-white font-bold mb-4">BharatDev</h3>
                  
                  <div className="bg-white/10 rounded-lg p-4 mb-4">
                    <div className="w-full h-24 bg-white/5 rounded-md mb-2"></div>
                    <div className="w-3/4 h-3 bg-white/5 rounded-md"></div>
                  </div>
                  
                  <div className="bg-white/10 rounded-lg p-4">
                    <div className="w-full h-24 bg-white/5 rounded-md mb-2"></div>
                    <div className="w-3/4 h-3 bg-white/5 rounded-md"></div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="absolute -top-4 -right-4 bg-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full">
              NEW!
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppDownload;
