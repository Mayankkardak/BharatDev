import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/hooks/use-i18n";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Menu, X, User, LogOut, Globe } from "lucide-react";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logoutMutation } = useAuth();
  const { t, language, setLanguage } = useI18n();
  const [location] = useLocation();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const closeMenu = () => setIsMenuOpen(false);

  const handleLogout = () => {
    logoutMutation.mutate();
    closeMenu();
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
    closeMenu();
  };

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <header className="sticky top-0 bg-white shadow-sm z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        {/* Logo */}
        <Link href="/" className="flex items-center space-x-2">
          <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
            <span className="text-white font-bold font-poppins text-lg">बD</span>
          </div>
          <span className="font-poppins font-semibold text-xl text-primary">Bharat<span className="text-orange-500">Dev</span></span>
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link href="/" className={`font-medium ${isActive('/') ? 'text-primary border-b-2 border-primary pb-1' : 'text-slate-600 hover:text-primary transition'}`}>
            {t("nav.home")}
          </Link>
          <Link href="/jobs" className={`font-medium ${isActive('/jobs') ? 'text-primary border-b-2 border-primary pb-1' : 'text-slate-600 hover:text-primary transition'}`}>
            {t("nav.jobs")}
          </Link>
          <Link href="/companies" className={`font-medium ${isActive('/companies') ? 'text-primary border-b-2 border-primary pb-1' : 'text-slate-600 hover:text-primary transition'}`}>
            {t("nav.companies")}
          </Link>
          <Link href="/resources" className={`font-medium ${isActive('/resources') ? 'text-primary border-b-2 border-primary pb-1' : 'text-slate-600 hover:text-primary transition'}`}>
            {t("nav.resources")}
          </Link>
        </nav>
        
        {/* Auth & Language - Desktop */}
        <div className="hidden md:flex items-center space-x-4">
          {/* Language Switcher */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="flex items-center space-x-1">
                <Globe className="h-4 w-4 mr-1" />
                <span>{language === 'en' ? 'EN' : 'हि'}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={toggleLanguage}>
                {language === 'en' ? t("language.hindi") : t("language.english")}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          {/* Auth Buttons */}
          {user ? (
            <div className="flex items-center space-x-2">
              <Link href="/profile">
                <Button variant="outline" size="sm" className="flex items-center">
                  <User className="h-4 w-4 mr-2" />
                  {t("nav.profile")}
                </Button>
              </Link>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
              >
                <LogOut className="h-4 w-4 mr-2" />
                {t("nav.logout")}
              </Button>
            </div>
          ) : (
            <>
              <Link href="/auth">
                <Button variant="ghost">{t("nav.signin")}</Button>
              </Link>
              <Link href="/auth">
                <Button>{t("nav.signup")}</Button>
              </Link>
            </>
          )}
        </div>
        
        {/* Mobile Menu Button */}
        <button 
          onClick={toggleMenu}
          className="md:hidden text-slate-700"
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 px-4 py-3">
          <nav className="flex flex-col space-y-3">
            <Link href="/" onClick={closeMenu} className={`font-medium ${isActive('/') ? 'text-primary' : 'text-slate-600'}`}>
              {t("nav.home")}
            </Link>
            <Link href="/jobs" onClick={closeMenu} className={`font-medium ${isActive('/jobs') ? 'text-primary' : 'text-slate-600'}`}>
              {t("nav.jobs")}
            </Link>
            <Link href="/companies" onClick={closeMenu} className={`font-medium ${isActive('/companies') ? 'text-primary' : 'text-slate-600'}`}>
              {t("nav.companies")}
            </Link>
            <Link href="/resources" onClick={closeMenu} className={`font-medium ${isActive('/resources') ? 'text-primary' : 'text-slate-600'}`}>
              {t("nav.resources")}
            </Link>
            
            <div className="pt-2 border-t border-slate-100 flex justify-between">
              <button 
                onClick={toggleLanguage}
                className="flex items-center space-x-1 text-sm font-medium py-1 pr-4"
              >
                <Globe className="h-4 w-4 mr-1" />
                <span>{language === 'en' ? t("language.english") : t("language.hindi")}</span>
              </button>
              
              <div className="flex space-x-4">
                {user ? (
                  <div className="flex flex-col space-y-2">
                    <Link href="/profile" onClick={closeMenu} className="text-primary font-medium">
                      {t("nav.profile")}
                    </Link>
                    <button 
                      onClick={handleLogout}
                      className="text-red-500 font-medium"
                      disabled={logoutMutation.isPending}
                    >
                      {t("nav.logout")}
                    </button>
                  </div>
                ) : (
                  <>
                    <Link href="/auth" onClick={closeMenu} className="text-primary font-medium">
                      {t("nav.signin")}
                    </Link>
                    <Link href="/auth" onClick={closeMenu} className="text-orange-500 font-medium">
                      {t("nav.signup")}
                    </Link>
                  </>
                )}
              </div>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
