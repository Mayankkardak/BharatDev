import { useI18n } from "@/hooks/use-i18n";
import { Link } from "wouter";
import { 
  Mail, 
  Phone, 
  Linkedin, 
  Twitter, 
  Instagram, 
  Facebook 
} from "lucide-react";

const Footer = () => {
  const { t } = useI18n();

  return (
    <footer className="bg-slate-900 text-slate-400 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-poppins font-semibold text-white mb-4">{t("app.name")}</h3>
            <ul className="space-y-2">
              <li><Link href="#" className="hover:text-white transition">{t("footer.about")}</Link></li>
              <li><Link href="#" className="hover:text-white transition">{t("footer.howItWorks")}</Link></li>
              <li><Link href="#" className="hover:text-white transition">{t("footer.success")}</Link></li>
              <li><Link href="#" className="hover:text-white transition">{t("footer.employers")}</Link></li>
              <li><Link href="#" className="hover:text-white transition">{t("footer.blog")}</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-poppins font-semibold text-white mb-4">{t("footer.jobCategories")}</h3>
            <ul className="space-y-2">
              <li><Link href="#" className="hover:text-white transition">Frontend Development</Link></li>
              <li><Link href="#" className="hover:text-white transition">Backend Development</Link></li>
              <li><Link href="#" className="hover:text-white transition">Full Stack</Link></li>
              <li><Link href="#" className="hover:text-white transition">Mobile Development</Link></li>
              <li><Link href="#" className="hover:text-white transition">DevOps</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-poppins font-semibold text-white mb-4">{t("footer.cities")}</h3>
            <ul className="space-y-2">
              <li><Link href="#" className="hover:text-white transition">Bangalore</Link></li>
              <li><Link href="#" className="hover:text-white transition">Hyderabad</Link></li>
              <li><Link href="#" className="hover:text-white transition">Mumbai</Link></li>
              <li><Link href="#" className="hover:text-white transition">Delhi NCR</Link></li>
              <li><Link href="#" className="hover:text-white transition">Pune</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-poppins font-semibold text-white mb-4">{t("footer.contact")}</h3>
            <ul className="space-y-2">
              <li>
                <a href="mailto:contact@bharatdev.com" className="hover:text-white transition flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  contact@bharatdev.com
                </a>
              </li>
              <li>
                <a href="tel:+911234567890" className="hover:text-white transition flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  +91 1234567890
                </a>
              </li>
            </ul>
            
            <h3 className="font-poppins font-semibold text-white mt-6 mb-4">{t("footer.follow")}</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-400 hover:text-white transition">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition">
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-slate-800 pt-8 mt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center mr-2">
              <span className="text-white font-bold font-poppins text-sm">बD</span>
            </div>
            <span className="text-white font-poppins">Bharat<span className="text-orange-500">Dev</span></span>
          </div>
          
          <div className="flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-6 text-sm">
            <Link href="#" className="hover:text-white transition text-center md:text-left">{t("footer.terms")}</Link>
            <Link href="#" className="hover:text-white transition text-center md:text-left">{t("footer.privacy")}</Link>
            <Link href="#" className="hover:text-white transition text-center md:text-left">{t("footer.cookies")}</Link>
            <div className="text-center md:text-left">{t("footer.copyright")}</div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
