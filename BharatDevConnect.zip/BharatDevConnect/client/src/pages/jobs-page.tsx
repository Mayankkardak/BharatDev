import { useState, useEffect } from "react";
import { useI18n } from "@/hooks/use-i18n";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { SearchFilters, FeaturedJob, JobType, JobExperienceLevel } from "@shared/types";
import JobCard from "@/components/jobs/JobCard";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Search, MapPin, X } from "lucide-react";
import { Link } from "wouter";

const JobsPage = () => {
  const { t } = useI18n();
  const [location] = useLocation();
  
  // Parse query params
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  const initialQuery = searchParams.get('q') || '';
  const initialLocation = searchParams.get('location') || '';
  
  // Local state for form fields
  const [searchFilters, setSearchFilters] = useState<SearchFilters>({
    query: initialQuery,
    location: initialLocation,
    jobType: [],
    experienceLevel: [],
    skills: [],
    salaryMin: 0,
    salaryMax: 100,
  });
  
  // Apply temp filters locally before submitting
  const [tempFilters, setTempFilters] = useState<SearchFilters>(searchFilters);
  
  // Update tempFilters whenever searchFilters change (e.g., from URL params)
  useEffect(() => {
    setTempFilters(searchFilters);
  }, [searchFilters]);
  
  const { data: jobs, isLoading } = useQuery<FeaturedJob[]>({
    queryKey: ['/api/jobs/search', searchFilters],
  });
  
  const handleFilterChange = (key: keyof SearchFilters, value: any) => {
    setTempFilters(prev => ({ ...prev, [key]: value }));
  };
  
  const handleJobTypeToggle = (type: JobType) => {
    setTempFilters(prev => {
      const currentTypes = prev.jobType || [];
      return {
        ...prev,
        jobType: currentTypes.includes(type)
          ? currentTypes.filter(t => t !== type)
          : [...currentTypes, type]
      };
    });
  };
  
  const handleExperienceLevelToggle = (level: JobExperienceLevel) => {
    setTempFilters(prev => {
      const currentLevels = prev.experienceLevel || [];
      return {
        ...prev,
        experienceLevel: currentLevels.includes(level)
          ? currentLevels.filter(l => l !== level)
          : [...currentLevels, level]
      };
    });
  };
  
  const handleSkillAdd = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && e.currentTarget.value.trim()) {
      const newSkill = e.currentTarget.value.trim();
      setTempFilters(prev => ({
        ...prev,
        skills: [...(prev.skills || []), newSkill]
      }));
      e.currentTarget.value = '';
    }
  };
  
  const handleSkillRemove = (skill: string) => {
    setTempFilters(prev => ({
      ...prev,
      skills: (prev.skills || []).filter(s => s !== skill)
    }));
  };
  
  const handleSalaryChange = (value: number[]) => {
    setTempFilters(prev => ({
      ...prev,
      salaryMin: value[0],
      salaryMax: value[1]
    }));
  };
  
  const applyFilters = () => {
    setSearchFilters(tempFilters);
  };
  
  const clearFilters = () => {
    const clearedFilters = {
      query: '',
      location: '',
      jobType: [],
      experienceLevel: [],
      skills: [],
      salaryMin: 0,
      salaryMax: 100,
    };
    setTempFilters(clearedFilters);
    setSearchFilters(clearedFilters);
  };
  
  const jobTypes: { value: JobType; label: string }[] = [
    { value: 'fulltime', label: t('job.type.fulltime') },
    { value: 'parttime', label: t('job.type.parttime') },
    { value: 'contract', label: t('job.type.contract') },
    { value: 'freelance', label: t('job.type.freelance') },
    { value: 'internship', label: t('job.type.internship') },
  ];
  
  const experienceLevels: { value: JobExperienceLevel; label: string }[] = [
    { value: 'entry', label: t('job.experience.entry') },
    { value: 'mid', label: t('job.experience.mid') },
    { value: 'senior', label: t('job.experience.senior') },
  ];

  return (
    <div className="bg-slate-50 py-8">
      <div className="container mx-auto px-4">
        {/* Search bar */}
        <div className="mb-8">
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-5 w-5 text-slate-400" />
                <Input
                  type="text"
                  placeholder={t("home.search.jobTitle")}
                  className="pl-10"
                  value={tempFilters.query}
                  onChange={e => handleFilterChange('query', e.target.value)}
                />
              </div>
              <div className="flex-1 relative">
                <MapPin className="absolute left-3 top-3 h-5 w-5 text-slate-400" />
                <Input
                  type="text"
                  placeholder={t("home.search.location")}
                  className="pl-10"
                  value={tempFilters.location}
                  onChange={e => handleFilterChange('location', e.target.value)}
                />
              </div>
              <Button 
                onClick={applyFilters}
                className="flex-shrink-0"
              >
                {t("home.search.button")}
              </Button>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="grid md:grid-cols-4 gap-6">
          {/* Filters sidebar */}
          <div className="md:col-span-1">
            <Card className="mb-4">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex justify-between items-center">
                  {t("job.filter.title")}
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={clearFilters}
                    className="text-sm text-slate-500 hover:text-red-500"
                  >
                    {t("job.filter.clear")}
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Job Type */}
                <div className="space-y-2">
                  <h3 className="font-medium text-sm">{t("job.filter.jobType")}</h3>
                  <div className="space-y-2">
                    {jobTypes.map(type => (
                      <div key={type.value} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`job-type-${type.value}`} 
                          checked={(tempFilters.jobType || []).includes(type.value)}
                          onCheckedChange={() => handleJobTypeToggle(type.value)}
                        />
                        <label 
                          htmlFor={`job-type-${type.value}`}
                          className="text-sm cursor-pointer"
                        >
                          {type.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Experience Level */}
                <div className="space-y-2">
                  <h3 className="font-medium text-sm">{t("job.filter.experience")}</h3>
                  <div className="space-y-2">
                    {experienceLevels.map(level => (
                      <div key={level.value} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`exp-level-${level.value}`} 
                          checked={(tempFilters.experienceLevel || []).includes(level.value)}
                          onCheckedChange={() => handleExperienceLevelToggle(level.value)}
                        />
                        <label 
                          htmlFor={`exp-level-${level.value}`}
                          className="text-sm cursor-pointer"
                        >
                          {level.label}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Salary Range */}
                <div className="space-y-2">
                  <h3 className="font-medium text-sm">{t("job.filter.salary")}</h3>
                  <div className="px-2">
                    <Slider
                      defaultValue={[tempFilters.salaryMin || 0, tempFilters.salaryMax || 100]}
                      max={100}
                      step={5}
                      onValueChange={handleSalaryChange}
                    />
                    <div className="flex justify-between mt-2 text-xs text-slate-500">
                      <span>{tempFilters.salaryMin}L INR</span>
                      <span>{tempFilters.salaryMax}L+ INR</span>
                    </div>
                  </div>
                </div>
                
                {/* Skills */}
                <div className="space-y-2">
                  <h3 className="font-medium text-sm">{t("job.filter.skills")}</h3>
                  <Input
                    placeholder="Add a skill and press Enter"
                    onKeyDown={handleSkillAdd}
                  />
                  <div className="flex flex-wrap gap-2 mt-2">
                    {(tempFilters.skills || []).map(skill => (
                      <Badge key={skill} variant="secondary" className="flex items-center gap-1">
                        {skill}
                        <button onClick={() => handleSkillRemove(skill)}>
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <Button onClick={applyFilters} className="w-full">
                  {t("job.filter.apply")}
                </Button>
              </CardContent>
            </Card>
          </div>
          
          {/* Jobs list */}
          <div className="md:col-span-3">
            <div className="flex justify-between items-center mb-4">
              {isLoading ? (
                <div>
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                </div>
              ) : (
                <div className="text-slate-600">
                  {jobs?.length || 0} jobs found
                </div>
              )}
            </div>
            
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3, 4, 5].map(i => (
                  <div key={i} className="bg-white rounded-lg p-6 shadow-sm animate-pulse">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center">
                        <div className="bg-slate-200 h-12 w-12 rounded-md mr-4"></div>
                        <div>
                          <div className="bg-slate-200 h-5 w-40 rounded mb-2"></div>
                          <div className="bg-slate-200 h-4 w-24 rounded"></div>
                        </div>
                      </div>
                    </div>
                    <div className="mb-4">
                      <div className="flex gap-2 mb-3">
                        <div className="bg-slate-200 h-6 w-16 rounded-full"></div>
                        <div className="bg-slate-200 h-6 w-20 rounded-full"></div>
                        <div className="bg-slate-200 h-6 w-16 rounded-full"></div>
                      </div>
                      <div className="flex gap-4">
                        <div className="bg-slate-200 h-4 w-24 rounded"></div>
                        <div className="bg-slate-200 h-4 w-24 rounded"></div>
                        <div className="bg-slate-200 h-4 w-24 rounded"></div>
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <div className="bg-slate-200 h-6 w-32 rounded-full"></div>
                      <div className="bg-slate-200 h-4 w-24 rounded"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : jobs && jobs.length > 0 ? (
              <div className="space-y-4">
                {jobs.map(job => (
                  <Link key={job.id} href={`/jobs/${job.id}`}>
                    <JobCard job={job} />
                  </Link>
                ))}
              </div>
            ) : (
              <Card className="text-center py-12">
                <CardContent>
                  <div className="flex flex-col items-center">
                    <Search className="h-12 w-12 text-slate-300 mb-4" />
                    <h3 className="text-xl font-medium mb-2">No jobs found</h3>
                    <p className="text-slate-500 mb-6">
                      {t("job.search.noResults")}
                    </p>
                    <Button onClick={clearFilters} variant="outline">
                      {t("job.filter.clear")}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobsPage;
