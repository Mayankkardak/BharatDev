import HeroSection from "@/components/home/HeroSection";
import StatsSection from "@/components/home/StatsSection";
import FeaturedJobs from "@/components/home/FeaturedJobs";
import AiMatchingSection from "@/components/home/AiMatchingSection";
import TopCompanies from "@/components/home/TopCompanies";
import Testimonials from "@/components/home/Testimonials";
import AppDownload from "@/components/home/AppDownload";
import SignUpCta from "@/components/home/SignUpCta";
import { useState, useEffect } from "react";

const HomePageContent = () => {
  return (
    <>
      <HeroSection />
      <StatsSection />
      <FeaturedJobs />
      <AiMatchingSection />
      <TopCompanies />
      <Testimonials />
      <AppDownload />
      <SignUpCta />
    </>
  );
};

// Error boundary as a simple component
const ErrorFallback = ({ error }: { error: Error }) => (
  <div className="container mx-auto px-4 py-16 text-center">
    <h2 className="text-2xl font-bold text-red-600 mb-4">Something went wrong:</h2>
    <pre className="bg-gray-100 p-4 rounded text-left overflow-x-auto">
      {error.message}
    </pre>
    <p className="mt-4">Please check the browser console for more details.</p>
  </div>
);

const HomePage = () => {
  const [error, setError] = useState<Error | null>(null);
  const [renderCount, setRenderCount] = useState(0);

  useEffect(() => {
    console.log('HomePage mounted');
    setRenderCount(prev => prev + 1);
    
    // For debugging - add a simple fallback if components don't load
    const timer = setTimeout(() => {
      if (document.querySelectorAll('section').length === 0) {
        console.log('No sections found, possible rendering issue');
      }
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  try {
    if (error) throw error;

    return (
      <div>
        <div className="fixed top-0 right-0 bg-blue-500 text-white px-2 py-1 text-xs z-50">
          Render #{renderCount}
        </div>
        <HomePageContent />
      </div>
    );
  } catch (err) {
    console.error('Error in HomePage:', err);
    return <ErrorFallback error={err instanceof Error ? err : new Error('Unknown error')} />;
  }
};

export default HomePage;
