import { useState } from "react";
import { useI18n } from "@/hooks/use-i18n";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { UserProfile } from "@shared/types";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Avatar,
  AvatarFallback,
  AvatarImage
} from "@/components/ui/avatar";
import {
  User as UserIcon,
  Briefcase,
  GraduationCap,
  MapPin,
  Phone,
  Plus,
  X,
  Loader2,
  Upload,
  CheckCircle,
  FileText
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Define the profile update schema
const profileSchema = z.object({
  fullName: z.string().min(2, { message: "Full name must be at least 2 characters" }),
  email: z.string().email({ message: "Invalid email address" }),
  bio: z.string().optional(),
  phone: z.string().optional(),
  location: z.string().optional(),
  experience: z.coerce.number().optional(),
  education: z.string().optional(),
  preferredLanguage: z.string(),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

const ProfilePage = () => {
  const { t } = useI18n();
  const { user } = useAuth();
  const { toast } = useToast();
  const [newSkill, setNewSkill] = useState("");
  const [selectedTab, setSelectedTab] = useState("personal");
  const [isUploading, setIsUploading] = useState(false);

  // Fetch profile data
  const { data: profile, isLoading } = useQuery<UserProfile>({
    queryKey: ["/api/profile"],
  });

  // Profile update mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: Partial<UserProfile>) => {
      const res = await apiRequest("PATCH", "/api/profile", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      toast({
        title: "Profile updated",
        description: "Your profile has been successfully updated",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Resume upload mutation
  const uploadResumeMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await fetch("/api/profile/resume", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(errorText || res.statusText);
      }
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      toast({
        title: "Resume uploaded",
        description: "Your resume has been successfully uploaded",
      });
      setIsUploading(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
      setIsUploading(false);
    },
  });

  // Skills update mutation
  const updateSkillsMutation = useMutation({
    mutationFn: async (skills: string[]) => {
      const res = await apiRequest("PATCH", "/api/profile/skills", { skills });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      toast({
        title: "Skills updated",
        description: "Your skills have been successfully updated",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Fetch applications
  const { data: applications, isLoading: isLoadingApplications } = useQuery({
    queryKey: ["/api/applications"],
  });

  // Fetch saved jobs
  const { data: savedJobs, isLoading: isLoadingSavedJobs } = useQuery({
    queryKey: ["/api/jobs/saved"],
  });

  // Form setup
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      fullName: profile?.fullName || "",
      email: profile?.email || "",
      bio: profile?.bio || "",
      phone: profile?.phone || "",
      location: profile?.location || "",
      experience: profile?.experience || 0,
      education: profile?.education || "",
      preferredLanguage: profile?.preferredLanguage || "en",
    },
    values: {
      fullName: profile?.fullName || "",
      email: profile?.email || "",
      bio: profile?.bio || "",
      phone: profile?.phone || "",
      location: profile?.location || "",
      experience: profile?.experience || 0,
      education: profile?.education || "",
      preferredLanguage: profile?.preferredLanguage || "en",
    },
  });

  // Handle form submission
  const onSubmit = (data: ProfileFormValues) => {
    updateProfileMutation.mutate(data);
  };

  // Add skill
  const handleAddSkill = () => {
    if (!newSkill.trim()) return;
    
    const updatedSkills = [...(profile?.skills || [])];
    if (!updatedSkills.includes(newSkill)) {
      updatedSkills.push(newSkill);
      updateSkillsMutation.mutate(updatedSkills);
      setNewSkill("");
    } else {
      toast({
        title: "Skill already exists",
        description: "This skill is already in your profile",
        variant: "destructive",
      });
    }
  };

  // Remove skill
  const handleRemoveSkill = (skill: string) => {
    const updatedSkills = (profile?.skills || []).filter(s => s !== skill);
    updateSkillsMutation.mutate(updatedSkills);
  };

  // Handle resume upload
  const handleResumeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    
    const file = e.target.files[0];
    const formData = new FormData();
    formData.append("resume", file);
    
    setIsUploading(true);
    uploadResumeMutation.mutate(formData);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[500px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="bg-slate-50 py-8">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl font-bold font-poppins mb-6">{t("profile.title")}</h1>
          
          <Tabs defaultValue="personal" value={selectedTab} onValueChange={setSelectedTab}>
            <TabsList className="grid grid-cols-4 mb-8">
              <TabsTrigger value="personal">{t("profile.personalInfo")}</TabsTrigger>
              <TabsTrigger value="skills">{t("profile.skills")}</TabsTrigger>
              <TabsTrigger value="resume">{t("profile.resume")}</TabsTrigger>
              <TabsTrigger value="applications">{t("profile.applications")}</TabsTrigger>
            </TabsList>
            
            {/* Personal Information Tab */}
            <TabsContent value="personal">
              <Card>
                <CardHeader>
                  <CardTitle>{t("profile.personalInfo")}</CardTitle>
                  <CardDescription>Update your personal details</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center mb-6">
                    <Avatar className="h-20 w-20 mr-4">
                      <AvatarImage src={profile?.avatar} alt={profile?.fullName} />
                      <AvatarFallback className="bg-primary text-white text-lg">
                        {profile?.fullName?.charAt(0) || user?.username?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h2 className="text-xl font-semibold">{profile?.fullName || user?.username}</h2>
                      <p className="text-slate-500">{profile?.email || user?.email}</p>
                    </div>
                  </div>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="fullName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("auth.fullName")}</FormLabel>
                              <FormControl>
                                <Input placeholder={t("auth.fullName")} {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("auth.email")}</FormLabel>
                              <FormControl>
                                <Input placeholder={t("auth.email")} {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("profile.phone")}</FormLabel>
                              <FormControl>
                                <Input placeholder={t("profile.phone")} {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="location"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("profile.location")}</FormLabel>
                              <FormControl>
                                <Input placeholder={t("profile.location")} {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="bio"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t("profile.bio")}</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder={t("profile.bio")} 
                                className="min-h-[100px]" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="preferredLanguage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Preferred Language</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select language" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="en">English</SelectItem>
                                <SelectItem value="hi">Hindi</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="flex justify-end">
                        <Button 
                          type="submit" 
                          disabled={updateProfileMutation.isPending}
                        >
                          {updateProfileMutation.isPending && (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          )}
                          {t("profile.save")}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Skills Tab */}
            <TabsContent value="skills">
              <Card>
                <CardHeader>
                  <CardTitle>{t("profile.skills")}</CardTitle>
                  <CardDescription>Add your professional skills and experience</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-8">
                    <h3 className="text-lg font-medium mb-4">Skills</h3>
                    
                    <div className="flex items-center mb-4">
                      <Input
                        placeholder="Add a new skill"
                        value={newSkill}
                        onChange={(e) => setNewSkill(e.target.value)}
                        className="max-w-sm mr-2"
                      />
                      <Button 
                        onClick={handleAddSkill}
                        size="sm"
                        disabled={updateSkillsMutation.isPending}
                      >
                        {updateSkillsMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Plus className="h-4 w-4 mr-2" />
                        )}
                        {t("profile.addSkill")}
                      </Button>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mt-2">
                      {(profile?.skills || []).map((skill) => (
                        <Badge key={skill} variant="secondary" className="px-3 py-1">
                          {skill}
                          <button 
                            onClick={() => handleRemoveSkill(skill)}
                            className="ml-1 text-slate-500 hover:text-red-500"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                      {(profile?.skills?.length || 0) === 0 && (
                        <p className="text-slate-500 text-sm">No skills added yet</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="experience"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("profile.experience")}</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="0" 
                                  min="0" 
                                  max="50" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>Years of professional experience</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="education"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("profile.education")}</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder={t("profile.education")}
                                  className="min-h-[100px]"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>Your academic qualifications</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="flex justify-end">
                          <Button 
                            type="submit" 
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending && (
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            )}
                            {t("profile.save")}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Resume Tab */}
            <TabsContent value="resume">
              <Card>
                <CardHeader>
                  <CardTitle>{t("profile.resume")}</CardTitle>
                  <CardDescription>Upload your resume or CV</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-6">
                    <h3 className="text-lg font-medium mb-2">Current Resume</h3>
                    {profile?.resumeUrl ? (
                      <div className="flex items-center p-4 bg-slate-50 rounded-lg">
                        <FileText className="h-8 w-8 text-primary mr-3" />
                        <div className="flex-1">
                          <p className="font-medium">Resume uploaded</p>
                          <a 
                            href={profile.resumeUrl} 
                            className="text-sm text-primary hover:underline"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            View resume
                          </a>
                        </div>
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      </div>
                    ) : (
                      <p className="text-slate-500">No resume uploaded yet</p>
                    )}
                  </div>
                  
                  <div className="border-2 border-dashed border-slate-200 rounded-lg p-8 text-center">
                    <div className="flex flex-col items-center justify-center">
                      <Upload className="h-10 w-10 text-slate-400 mb-4" />
                      <h3 className="text-lg font-medium mb-2">{t("profile.uploadResume")}</h3>
                      <p className="text-slate-500 mb-4 max-w-md">
                        Upload your resume or CV in PDF, DOC, or DOCX format
                      </p>
                      <label htmlFor="resume-upload">
                        <div className="cursor-pointer">
                          <Button 
                            disabled={isUploading}
                            className="cursor-pointer"
                          >
                            {isUploading ? (
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            ) : (
                              <Upload className="mr-2 h-4 w-4" />
                            )}
                            Browse Files
                          </Button>
                          <input
                            id="resume-upload"
                            type="file"
                            accept=".pdf,.doc,.docx"
                            className="hidden"
                            onChange={handleResumeUpload}
                          />
                        </div>
                      </label>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Applications Tab */}
            <TabsContent value="applications">
              <Card>
                <CardHeader>
                  <CardTitle>{t("profile.applications")}</CardTitle>
                  <CardDescription>Track your job applications</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingApplications ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : applications && applications.length > 0 ? (
                    <div className="space-y-4">
                      {applications.map((application: any) => (
                        <div key={application.id} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">{application.job.title}</h3>
                              <p className="text-sm text-slate-500">{application.job.companyName}</p>
                              <div className="flex items-center mt-2">
                                <Badge variant={
                                  application.status === 'accepted' ? 'success' :
                                  application.status === 'rejected' ? 'destructive' :
                                  'secondary'
                                }>
                                  {application.status}
                                </Badge>
                                <span className="text-xs text-slate-500 ml-2">
                                  Applied on {new Date(application.createdAt).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                            <Button variant="outline" size="sm" asChild>
                              <a href={`/jobs/${application.job.id}`}>View Job</a>
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Briefcase className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No applications yet</h3>
                      <p className="text-slate-500 mb-4">
                        Start applying to jobs to track your applications here
                      </p>
                      <Button asChild>
                        <a href="/jobs">Browse Jobs</a>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              {/* Saved Jobs Section */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>{t("profile.saved")}</CardTitle>
                  <CardDescription>Jobs you've saved for later</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingSavedJobs ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : savedJobs && savedJobs.length > 0 ? (
                    <div className="space-y-4">
                      {savedJobs.map((job: any) => (
                        <div key={job.id} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">{job.title}</h3>
                              <p className="text-sm text-slate-500">{job.companyName}</p>
                              <div className="flex flex-wrap gap-2 mt-2">
                                {job.skills.slice(0, 3).map((skill: string) => (
                                  <Badge key={skill} variant="secondary" className="text-xs">
                                    {skill}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <Button variant="outline" size="sm" asChild>
                              <a href={`/jobs/${job.id}`}>View Job</a>
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Bookmark className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">No saved jobs</h3>
                      <p className="text-slate-500 mb-4">
                        Save jobs you're interested in to view them later
                      </p>
                      <Button asChild>
                        <a href="/jobs">Browse Jobs</a>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
