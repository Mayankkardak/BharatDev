import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";
import { insertJobSchema, insertApplicationSchema, insertTestimonialSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  const { isAuthenticated } = setupAuth(app);

  // Configure multer for file uploads
  const uploadDir = path.join(process.cwd(), "uploads");
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }

  const storage_config = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueFilename = `${uuidv4()}-${file.originalname}`;
      cb(null, uniqueFilename);
    },
  });

  const upload = multer({
    storage: storage_config,
    limits: {
      fileSize: 5 * 1024 * 1024, // 5MB limit
    },
    fileFilter: (req, file, cb) => {
      const allowedTypes = ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error("Only PDF, DOC, and DOCX files are allowed"));
      }
    },
  });

  // Profile routes
  app.get("/api/profile", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error fetching profile", error: (error as Error).message });
    }
  });

  app.patch("/api/profile", isAuthenticated, async (req, res) => {
    try {
      const updateData = req.body;
      const updatedUser = await storage.updateUser(req.user!.id, updateData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error updating profile", error: (error as Error).message });
    }
  });

  app.patch("/api/profile/skills", isAuthenticated, async (req, res) => {
    try {
      const { skills } = req.body;
      if (!Array.isArray(skills)) {
        return res.status(400).json({ message: "Skills must be an array" });
      }
      
      const updatedUser = await storage.updateUser(req.user!.id, { skills });
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error updating skills", error: (error as Error).message });
    }
  });

  app.post("/api/profile/resume", isAuthenticated, upload.single("resume"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const resumeUrl = `/uploads/${req.file.filename}`;
      const updatedUser = await storage.updateUser(req.user!.id, { resumeUrl });
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error uploading resume", error: (error as Error).message });
    }
  });

  // Jobs routes
  app.get("/api/jobs/featured", async (req, res) => {
    try {
      const featuredJobs = await storage.getFeaturedJobs();
      res.json(featuredJobs);
    } catch (error) {
      res.status(500).json({ message: "Error fetching featured jobs", error: (error as Error).message });
    }
  });

  app.get("/api/jobs/search", async (req, res) => {
    try {
      const filters = {
        query: req.query.q as string,
        location: req.query.location as string,
        jobType: req.query.jobType ? (req.query.jobType as string).split(",") : undefined,
        experienceLevel: req.query.experienceLevel ? (req.query.experienceLevel as string).split(",") : undefined,
        skills: req.query.skills ? (req.query.skills as string).split(",") : undefined,
        salaryMin: req.query.salaryMin ? parseInt(req.query.salaryMin as string) : undefined,
        salaryMax: req.query.salaryMax ? parseInt(req.query.salaryMax as string) : undefined,
      };
      
      const jobs = await storage.searchJobs(filters);
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Error searching jobs", error: (error as Error).message });
    }
  });

  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const job = await storage.getJob(jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Error fetching job", error: (error as Error).message });
    }
  });

  app.post("/api/jobs", isAuthenticated, async (req, res) => {
    try {
      const jobData = insertJobSchema.parse(req.body);
      const job = await storage.createJob(jobData);
      res.status(201).json(job);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid job data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating job", error: (error as Error).message });
    }
  });

  // Applications routes
  app.get("/api/applications", isAuthenticated, async (req, res) => {
    try {
      const applications = await storage.getUserApplications(req.user!.id);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: "Error fetching applications", error: (error as Error).message });
    }
  });

  app.post("/api/applications", isAuthenticated, async (req, res) => {
    try {
      const applicationData = insertApplicationSchema.parse({
        ...req.body,
        userId: req.user!.id,
      });
      
      const application = await storage.createApplication(applicationData);
      res.status(201).json(application);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid application data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating application", error: (error as Error).message });
    }
  });

  // Saved jobs routes
  app.get("/api/jobs/saved", isAuthenticated, async (req, res) => {
    try {
      const savedJobs = await storage.getUserSavedJobs(req.user!.id);
      res.json(savedJobs);
    } catch (error) {
      res.status(500).json({ message: "Error fetching saved jobs", error: (error as Error).message });
    }
  });

  app.post("/api/jobs/:id/save", isAuthenticated, async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      await storage.saveJob(req.user!.id, jobId);
      res.status(200).json({ message: "Job saved successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error saving job", error: (error as Error).message });
    }
  });

  app.delete("/api/jobs/:id/save", isAuthenticated, async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      await storage.unsaveJob(req.user!.id, jobId);
      res.status(200).json({ message: "Job removed from saved" });
    } catch (error) {
      res.status(500).json({ message: "Error removing saved job", error: (error as Error).message });
    }
  });

  // Companies routes
  app.get("/api/companies/top", async (req, res) => {
    try {
      const companies = await storage.getTopCompanies();
      res.json(companies);
    } catch (error) {
      res.status(500).json({ message: "Error fetching top companies", error: (error as Error).message });
    }
  });

  app.get("/api/companies/:id", async (req, res) => {
    try {
      const companyId = parseInt(req.params.id);
      const company = await storage.getCompany(companyId);
      
      if (!company) {
        return res.status(404).json({ message: "Company not found" });
      }
      
      res.json(company);
    } catch (error) {
      res.status(500).json({ message: "Error fetching company", error: (error as Error).message });
    }
  });

  // Testimonials routes
  app.get("/api/testimonials", async (req, res) => {
    try {
      const testimonials = await storage.getTestimonials();
      res.json(testimonials);
    } catch (error) {
      res.status(500).json({ message: "Error fetching testimonials", error: (error as Error).message });
    }
  });

  app.post("/api/testimonials", isAuthenticated, async (req, res) => {
    try {
      const testimonialData = insertTestimonialSchema.parse({
        ...req.body,
        userId: req.user!.id,
      });
      
      const testimonial = await storage.createTestimonial(testimonialData);
      res.status(201).json(testimonial);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid testimonial data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating testimonial", error: (error as Error).message });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
