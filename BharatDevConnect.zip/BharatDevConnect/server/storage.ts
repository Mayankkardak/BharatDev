import { 
  users, 
  type User, 
  type InsertUser, 
  jobs,
  type Job,
  type InsertJob,
  companies,
  type Company,
  type InsertCompany,
  applications,
  type Application,
  type InsertApplication,
  testimonials,
  type Testimonial,
  type InsertTestimonial
} from "@shared/schema";
import { SearchFilters, FeaturedJob, CompanyInfo } from "@shared/types";

// interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User>;
  
  // Job operations
  getJob(id: number): Promise<Job | undefined>;
  getFeaturedJobs(): Promise<FeaturedJob[]>;
  searchJobs(filters: SearchFilters): Promise<FeaturedJob[]>;
  createJob(job: InsertJob): Promise<Job>;
  
  // Company operations
  getCompany(id: number): Promise<Company | undefined>;
  getTopCompanies(): Promise<CompanyInfo[]>;
  createCompany(company: InsertCompany): Promise<Company>;
  
  // Application operations
  getUserApplications(userId: number): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  
  // Saved jobs operations
  getUserSavedJobs(userId: number): Promise<FeaturedJob[]>;
  saveJob(userId: number, jobId: number): Promise<void>;
  unsaveJob(userId: number, jobId: number): Promise<void>;
  
  // Testimonial operations
  getTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private jobs: Map<number, Job>;
  private companies: Map<number, Company>;
  private applications: Map<number, Application>;
  private savedJobs: Map<number, Set<number>>;
  private testimonials: Map<number, Testimonial>;
  
  private nextUserId: number;
  private nextJobId: number;
  private nextCompanyId: number;
  private nextApplicationId: number;
  private nextTestimonialId: number;

  constructor() {
    this.users = new Map();
    this.jobs = new Map();
    this.companies = new Map();
    this.applications = new Map();
    this.savedJobs = new Map();
    this.testimonials = new Map();
    
    this.nextUserId = 1;
    this.nextJobId = 1;
    this.nextCompanyId = 1;
    this.nextApplicationId = 1;
    this.nextTestimonialId = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.nextUserId++;
    const timestamp = new Date();
    
    const user: User = {
      id,
      ...userData,
      skills: userData.skills || [],
      isVerified: false,
      createdAt: timestamp,
    };
    
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, data: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Job operations
  async getJob(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async getFeaturedJobs(): Promise<FeaturedJob[]> {
    // Convert jobs to FeaturedJob format
    return Array.from(this.jobs.values())
      .filter(job => job.isActive)
      .slice(0, 6) // Limit to 6 featured jobs
      .map(job => this.convertToFeaturedJob(job));
  }

  async searchJobs(filters: SearchFilters): Promise<FeaturedJob[]> {
    let filteredJobs = Array.from(this.jobs.values()).filter(job => job.isActive);
    
    // Apply filters
    if (filters.query) {
      const query = filters.query.toLowerCase();
      filteredJobs = filteredJobs.filter(job => 
        job.title.toLowerCase().includes(query) || 
        job.description.toLowerCase().includes(query) ||
        job.skills.some(skill => skill.toLowerCase().includes(query))
      );
    }
    
    if (filters.location) {
      const location = filters.location.toLowerCase();
      filteredJobs = filteredJobs.filter(job => 
        job.location.toLowerCase().includes(location)
      );
    }
    
    if (filters.jobType && filters.jobType.length > 0) {
      filteredJobs = filteredJobs.filter(job => 
        filters.jobType!.includes(job.employmentType as any)
      );
    }
    
    if (filters.experienceLevel && filters.experienceLevel.length > 0) {
      filteredJobs = filteredJobs.filter(job => 
        filters.experienceLevel!.includes(job.experienceLevel as any)
      );
    }
    
    if (filters.skills && filters.skills.length > 0) {
      filteredJobs = filteredJobs.filter(job => 
        filters.skills!.some(skill => 
          job.skills.some(jobSkill => 
            jobSkill.toLowerCase().includes(skill.toLowerCase())
          )
        )
      );
    }
    
    if (filters.salaryMin !== undefined || filters.salaryMax !== undefined) {
      filteredJobs = filteredJobs.filter(job => {
        // Extract numeric salary from format like "20-30 LPA"
        const salaryMatch = job.salary?.match(/(\d+)(?:-(\d+))?\s*LPA/i);
        if (!salaryMatch) return true; // Include if no salary specified
        
        const minSalary = parseInt(salaryMatch[1]);
        const maxSalary = salaryMatch[2] ? parseInt(salaryMatch[2]) : minSalary;
        
        // Check if job salary range overlaps with filter range
        return (filters.salaryMin === undefined || maxSalary >= filters.salaryMin) &&
               (filters.salaryMax === undefined || minSalary <= filters.salaryMax);
      });
    }
    
    // Convert to FeaturedJob format
    return filteredJobs.map(job => this.convertToFeaturedJob(job));
  }

  async createJob(jobData: InsertJob): Promise<Job> {
    const id = this.nextJobId++;
    const timestamp = new Date();
    
    const job: Job = {
      id,
      ...jobData,
      isActive: true,
      createdAt: timestamp,
    };
    
    this.jobs.set(id, job);
    return job;
  }

  // Company operations
  async getCompany(id: number): Promise<Company | undefined> {
    return this.companies.get(id);
  }

  async getTopCompanies(): Promise<CompanyInfo[]> {
    // Get top companies based on number of active jobs
    const companies = Array.from(this.companies.values());
    const jobsByCompany = Array.from(this.jobs.values())
      .filter(job => job.isActive)
      .reduce((acc, job) => {
        acc[job.companyId] = (acc[job.companyId] || 0) + 1;
        return acc;
      }, {} as Record<number, number>);
    
    return companies
      .slice(0, 6) // Limit to 6 companies
      .map(company => ({
        id: company.id,
        name: company.name,
        logo: company.logo || "",
        openJobs: jobsByCompany[company.id] || 0,
      }));
  }

  async createCompany(companyData: InsertCompany): Promise<Company> {
    const id = this.nextCompanyId++;
    const timestamp = new Date();
    
    const company: Company = {
      id,
      ...companyData,
      isVerified: false,
      createdAt: timestamp,
    };
    
    this.companies.set(id, company);
    return company;
  }

  // Application operations
  async getUserApplications(userId: number): Promise<Application[]> {
    return Array.from(this.applications.values())
      .filter(app => app.userId === userId);
  }

  async createApplication(applicationData: InsertApplication): Promise<Application> {
    const id = this.nextApplicationId++;
    const timestamp = new Date();
    
    const application: Application = {
      id,
      ...applicationData,
      status: "pending",
      createdAt: timestamp,
    };
    
    this.applications.set(id, application);
    return application;
  }

  // Saved jobs operations
  async getUserSavedJobs(userId: number): Promise<FeaturedJob[]> {
    const savedJobIds = this.savedJobs.get(userId) || new Set();
    return Array.from(savedJobIds)
      .map(jobId => this.jobs.get(jobId))
      .filter((job): job is Job => job !== undefined)
      .map(job => this.convertToFeaturedJob(job));
  }

  async saveJob(userId: number, jobId: number): Promise<void> {
    if (!this.savedJobs.has(userId)) {
      this.savedJobs.set(userId, new Set());
    }
    this.savedJobs.get(userId)!.add(jobId);
  }

  async unsaveJob(userId: number, jobId: number): Promise<void> {
    if (this.savedJobs.has(userId)) {
      this.savedJobs.get(userId)!.delete(jobId);
    }
  }

  // Testimonial operations
  async getTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values())
      .filter(testimonial => testimonial.isApproved);
  }

  async createTestimonial(testimonialData: InsertTestimonial): Promise<Testimonial> {
    const id = this.nextTestimonialId++;
    const timestamp = new Date();
    
    const testimonial: Testimonial = {
      id,
      ...testimonialData,
      isApproved: false,
      createdAt: timestamp,
    };
    
    this.testimonials.set(id, testimonial);
    return testimonial;
  }

  // Helper method to convert Job to FeaturedJob format
  private convertToFeaturedJob(job: Job): FeaturedJob {
    const company = this.companies.get(job.companyId);
    return {
      id: job.id,
      title: job.title,
      companyName: company?.name || "Unknown Company",
      companyLogo: company?.logo || "",
      location: job.location,
      salary: job.salary || "Not specified",
      experience: job.experienceLevel || "Not specified",
      skills: job.skills || [],
      isVerified: company?.isVerified || false,
      postedAt: this.getRelativeTime(job.createdAt),
    };
  }

  // Helper to get relative time (e.g. "3 days ago")
  private getRelativeTime(date: Date): string {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return "Today";
    } else if (diffDays === 1) {
      return "Yesterday";
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else if (diffDays < 30) {
      return `${Math.floor(diffDays / 7)} weeks ago`;
    } else {
      return `${Math.floor(diffDays / 30)} months ago`;
    }
  }

  // Initialize with sample data
  private initializeSampleData() {
    // Create sample companies
    const companyIds = [
      this.createSampleCompany({
        name: "Google",
        logo: "https://logo.clearbit.com/google.com",
        website: "https://google.com",
        description: "Google LLC is an American multinational technology company focusing on search engine technology, online advertising, cloud computing, computer software, quantum computing, e-commerce, and artificial intelligence.",
        industry: "Technology",
        size: "10000+",
        location: "Bangalore",
        isVerified: true,
        userId: 1,
      }),
      this.createSampleCompany({
        name: "Microsoft",
        logo: "https://logo.clearbit.com/microsoft.com",
        website: "https://microsoft.com",
        description: "Microsoft Corporation is an American multinational technology corporation which produces computer software, consumer electronics, personal computers, and related services.",
        industry: "Technology",
        size: "10000+",
        location: "Hyderabad",
        isVerified: true,
        userId: 1,
      }),
      this.createSampleCompany({
        name: "Amazon",
        logo: "https://logo.clearbit.com/amazon.com",
        website: "https://amazon.com",
        description: "Amazon.com, Inc. is an American multinational technology company focusing on e-commerce, cloud computing, digital streaming, and artificial intelligence.",
        industry: "Technology",
        size: "10000+",
        location: "Bangalore",
        isVerified: true,
        userId: 1,
      }),
      this.createSampleCompany({
        name: "Flipkart",
        logo: "https://logo.clearbit.com/flipkart.com",
        website: "https://flipkart.com",
        description: "Flipkart is an Indian e-commerce company, headquartered in Bangalore, and incorporated in Singapore as a private limited company.",
        industry: "E-commerce",
        size: "5000-10000",
        location: "Bangalore",
        isVerified: true,
        userId: 1,
      }),
      this.createSampleCompany({
        name: "Infosys",
        logo: "https://logo.clearbit.com/infosys.com",
        website: "https://infosys.com",
        description: "Infosys Limited is an Indian multinational information technology company that provides business consulting, information technology and outsourcing services.",
        industry: "IT Services",
        size: "10000+",
        location: "Bangalore",
        isVerified: true,
        userId: 1,
      }),
      this.createSampleCompany({
        name: "TCS",
        logo: "https://logo.clearbit.com/tcs.com",
        website: "https://tcs.com",
        description: "Tata Consultancy Services is an Indian multinational information technology services and consulting company headquartered in Mumbai.",
        industry: "IT Services",
        size: "10000+",
        location: "Mumbai",
        isVerified: true,
        userId: 1,
      }),
    ];

    // Create sample jobs
    this.createSampleJob({
      title: "Senior Frontend Engineer",
      description: "We are looking for a Senior Frontend Engineer to join our team to build world-class web applications.",
      requirements: "5+ years of experience with modern JavaScript frameworks, preferably React. Strong understanding of web technologies and performance optimization.",
      responsibilities: "Develop and maintain complex web applications, collaborate with designers and backend engineers, and mentor junior developers.",
      location: "Bangalore",
      salary: "25-35 LPA",
      experienceLevel: "senior",
      employmentType: "fulltime",
      skills: ["React", "TypeScript", "Next.js"],
      companyId: companyIds[0],
      isActive: true,
    });

    this.createSampleJob({
      title: "Backend Developer",
      description: "Join our backend team to build scalable and robust APIs and services.",
      requirements: "3+ years of experience with Java and Spring Boot. Familiarity with AWS services and microservices architecture.",
      responsibilities: "Design and implement backend services, optimize database queries, and ensure scalability and reliability of systems.",
      location: "Hyderabad",
      salary: "20-30 LPA",
      experienceLevel: "mid",
      employmentType: "fulltime",
      skills: ["Java", "Spring Boot", "AWS"],
      companyId: companyIds[1],
      isActive: true,
    });

    this.createSampleJob({
      title: "Full Stack Developer",
      description: "Looking for a talented Full Stack Developer to work on our consumer-facing applications.",
      requirements: "2+ years of experience with React and Node.js. Experience with MongoDB and RESTful APIs.",
      responsibilities: "Build and maintain full-stack web applications, collaborate with product managers and designers, and implement new features.",
      location: "Remote",
      salary: "15-22 LPA",
      experienceLevel: "mid",
      employmentType: "fulltime",
      skills: ["React", "Node.js", "MongoDB"],
      companyId: companyIds[2],
      isActive: true,
    });

    this.createSampleJob({
      title: "DevOps Engineer",
      description: "Help us build and maintain our cloud infrastructure and CI/CD pipelines.",
      requirements: "3+ years of experience with AWS, Docker, and Kubernetes. Familiarity with CI/CD tools and Infrastructure as Code.",
      responsibilities: "Manage and optimize cloud infrastructure, implement and maintain CI/CD pipelines, and ensure reliability and security.",
      location: "Bangalore",
      salary: "18-28 LPA",
      experienceLevel: "mid",
      employmentType: "fulltime",
      skills: ["AWS", "Docker", "Kubernetes", "CI/CD"],
      companyId: companyIds[3],
      isActive: true,
    });

    this.createSampleJob({
      title: "Mobile Developer (Android)",
      description: "Join our mobile team to build innovative Android applications.",
      requirements: "2+ years of experience with Android development using Kotlin. Familiarity with modern Android architecture components.",
      responsibilities: "Develop and maintain Android applications, collaborate with designers and backend engineers, and optimize app performance.",
      location: "Pune",
      salary: "12-18 LPA",
      experienceLevel: "mid",
      employmentType: "fulltime",
      skills: ["Android", "Kotlin", "MVVM"],
      companyId: companyIds[4],
      isActive: true,
    });

    this.createSampleJob({
      title: "Data Scientist",
      description: "Help us extract insights from data and build machine learning models.",
      requirements: "2+ years of experience with data analysis and machine learning. Proficiency in Python and its data science libraries.",
      responsibilities: "Analyze data, build and deploy machine learning models, and collaborate with product teams to implement data-driven features.",
      location: "Bangalore",
      salary: "15-25 LPA",
      experienceLevel: "mid",
      employmentType: "fulltime",
      skills: ["Python", "Machine Learning", "TensorFlow", "SQL"],
      companyId: companyIds[0],
      isActive: true,
    });

    // Create sample testimonials
    this.createSampleTestimonial({
      userId: 1,
      content: "BharatDev helped me find a remote position at a global tech company that values work-life balance. The AI matching was spot on!",
      companyName: "Google",
      jobTitle: "Frontend Developer",
      isApproved: true,
    });

    this.createSampleTestimonial({
      userId: 1,
      content: "As a developer from a small town, BharatDev connected me with opportunities I never thought possible. Now I work for a US-based startup!",
      companyName: "Stripe",
      jobTitle: "Backend Engineer",
      isApproved: true,
    });

    this.createSampleTestimonial({
      userId: 1,
      content: "The Hindi language support made all the difference for me. I found a job that values my technical skills despite my limited English proficiency.",
      companyName: "Razorpay",
      jobTitle: "Full Stack Developer",
      isApproved: true,
    });
  }

  // Helper methods to create sample data
  private createSampleCompany(data: Partial<Company>): number {
    const id = this.nextCompanyId++;
    const timestamp = new Date();
    const company: Company = {
      id,
      name: data.name || "Sample Company",
      logo: data.logo,
      website: data.website,
      description: data.description,
      industry: data.industry,
      size: data.size,
      location: data.location,
      isVerified: data.isVerified || false,
      userId: data.userId,
      createdAt: timestamp,
    };
    this.companies.set(id, company);
    return id;
  }

  private createSampleJob(data: Partial<Job>): number {
    const id = this.nextJobId++;
    const timestamp = new Date();
    // Adjust creation date for relative time display
    const randomDaysAgo = Math.floor(Math.random() * 14); // Random days in the past (0-14)
    timestamp.setDate(timestamp.getDate() - randomDaysAgo);
    
    const job: Job = {
      id,
      title: data.title || "Sample Job",
      description: data.description || "Sample description",
      requirements: data.requirements || "Sample requirements",
      responsibilities: data.responsibilities || "Sample responsibilities",
      location: data.location || "Sample location",
      salary: data.salary,
      experienceLevel: data.experienceLevel,
      employmentType: data.employmentType || "fulltime",
      skills: data.skills || [],
      companyId: data.companyId || 1,
      isActive: data.isActive !== undefined ? data.isActive : true,
      createdAt: timestamp,
    };
    this.jobs.set(id, job);
    return id;
  }

  private createSampleTestimonial(data: Partial<Testimonial>): number {
    const id = this.nextTestimonialId++;
    const timestamp = new Date();
    
    const testimonial: Testimonial = {
      id,
      userId: data.userId || 1,
      content: data.content || "Sample testimonial",
      companyName: data.companyName,
      jobTitle: data.jobTitle,
      isApproved: data.isApproved !== undefined ? data.isApproved : false,
      createdAt: timestamp,
    };
    this.testimonials.set(id, testimonial);
    return id;
  }
}

export const storage = new MemStorage();
